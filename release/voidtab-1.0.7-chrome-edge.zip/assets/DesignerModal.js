import{d as tt,r as T,c as S,f as g,j as h,A as Gt,p as t,D as B,M as Kt,C as Bt,F as u,u as b,L as x,B as H,S as y,U as z,H as f,l as $,E as yt,J as L,K as j,w as bt,I as Ft,a5 as Yt,_ as K,a3 as Zt,G as Qt,T as Xt}from"./vendor-vue.js";import{_ as et,aE as kt,aF as te,aG as ee,aH as ae,u as St,e as zt,S as Tt,at as ne,ar as se,d as X,b as xt,ak as ie,aI as oe,G as Dt,ai as re,o as le,aJ as ce,ap as de,j as pe,aK as me,a2 as ue,g as ge,n as ve,a as be,ac as xe}from"./main.js";import{G as he}from"./PhFloppyDisk.vue.js";import{G as nt}from"./PhMagicWand.vue.js";import{H as fe}from"./PhPlay.vue.js";import{H as M,j as we,c as ye,a as ke,x as Se}from"./vendor-markdown.js";import{G as ze}from"./PhArrowsClockwise.vue.js";import{I as Te}from"./PhClipboard.vue.js";import{f as De}from"./keys.js";import{r as _e}from"./aiStream.js";import"./vendor-data.js";import"./vendor-dnd.js";import"./vendor-core.js";import"./vendor-widgets-time.js";const Ce=["innerHTML"],Ae=["value","placeholder"],Ne=tt({__name:"CodeEditor",props:{modelValue:{},language:{default:"javascript"},rows:{default:12},placeholder:{default:""}},emits:["update:modelValue"],setup(n,{emit:r}){M.getLanguage("javascript")||M.registerLanguage("javascript",we),M.getLanguage("css")||M.registerLanguage("css",ye),M.getLanguage("json")||M.registerLanguage("json",ke),M.getLanguage("xml")||M.registerLanguage("xml",Se);const a=n,c=r,d=T(null),p=v=>v.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),s=S(()=>{const v=a.modelValue??"",k=a.language&&M.getLanguage(a.language)?a.language:"";let A;try{A=k?M.highlight(v,{language:k}).value:p(v)}catch{A=p(v)}return A+`
`}),E=v=>c("update:modelValue",v.target.value),_=v=>{const k=v.target;d.value&&(d.value.scrollTop=k.scrollTop,d.value.scrollLeft=k.scrollLeft)};return(v,k)=>(g(),h("div",{class:"code-editor",style:Gt({"--ce-rows":n.rows})},[t("pre",{ref_key:"preRef",ref:d,class:"ce-pre","aria-hidden":"true"},[t("code",{class:"hljs",innerHTML:s.value},null,8,Ce)],512),t("textarea",{class:"ce-ta",value:n.modelValue,placeholder:n.placeholder,spellcheck:"false",autocapitalize:"off",autocomplete:"off",autocorrect:"off",wrap:"off",onInput:E,onScroll:_},null,40,Ae)],4))}}),U=et(Ne,[["__scopeId","data-v-c2d16cd2"]]),at="index.js",ht={storage:{label:"实例存储",detail:"读写本实例自己的本地小容量数据（ctx.storage）"},network:{label:"网络代理",detail:"经宿主访问清单声明的域名（ctx.network.fetch，仅 GET/HEAD）"},openExternal:{label:"打开外链",detail:"在新标签页打开经校验的 URL（ctx.openUrl）"},"clipboard.write":{label:"写入剪贴板",detail:"把文本写入系统剪贴板（ctx.copyText）"},notifications:{label:"系统通知",detail:"在浏览器授权后发送本地通知（ctx.notify）"}},P=n=>({w:n.w,h:n.h});function ft(n=Date.now()){const r=Math.random().toString(36).slice(2,6),a=rt[0].draft(n);return{id:`my.widget-${r}`,label:"我的组件",description:"",icon:"Code",category:"local",version:"0.1.0",sizes:{default:{w:2,h:2},min:{w:1,h:1},max:{w:4,h:4}},permissions:a.permissions.slice(),networkHosts:a.networkHosts.slice(),entryCode:a.entryCode,styles:a.styles,modalHtml:a.modalHtml,modalStyles:a.modalStyles,modalWidth:a.modalWidth,modalHeight:a.modalHeight,html:"",settingsSchemaText:a.settingsSchemaText}}function Ee(n,r){const a=[];return n.includes("storage")&&a.push({type:"storage",scope:"instance"}),n.includes("network")&&a.push({type:"network",hosts:r.map(c=>c.trim()).filter(Boolean)}),n.includes("openExternal")&&a.push({type:"openExternal"}),n.includes("clipboard.write")&&a.push({type:"clipboard.write"}),n.includes("notifications")&&a.push({type:"notifications"}),a}function Ie(n){const r=[];let a=[];for(const c of n||[])c.type==="storage"?r.push("storage"):c.type==="network"?(r.push("network"),a=(c.hosts||[]).slice()):c.type==="openExternal"?r.push("openExternal"):c.type==="clipboard.write"?r.push("clipboard.write"):c.type==="notifications"&&r.push("notifications");return{permissions:r,networkHosts:a}}const st="/* voidtab-designer-modal:start */",it="/* voidtab-designer-modal:end */";function He(n){const r={title:n.label.trim()||n.id.trim()||"详情",html:n.modalHtml||"",styles:n.modalStyles||"",width:n.modalWidth||"",height:n.modalHeight||""};return`${st}
const __VOIDTAB_DESIGNER_MODAL__ = JSON.parse(${JSON.stringify(JSON.stringify(r))});
window.VoidTabDesigner = Object.freeze({
  modal: __VOIDTAB_DESIGNER_MODAL__,
  escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, (char) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    })[char] || char);
  },
  openModal(ctx, overrides) {
    const next = Object.assign({}, __VOIDTAB_DESIGNER_MODAL__, overrides || {});
    return ctx.modal.open(next);
  },
  updateModal(ctx, overrides) {
    const next = Object.assign({}, __VOIDTAB_DESIGNER_MODAL__, overrides || {});
    return ctx.modal.update ? ctx.modal.update(next) : ctx.modal.open(next);
  }
});
${it}`}function $e(n){return`${He(n)}

${n.entryCode||""}`}function Ve(n){const r=n.indexOf(st),a=n.indexOf(it);if(r<0||a<r)return{entryCode:n,modalHtml:"",modalStyles:"",modalWidth:"",modalHeight:""};const c=n.slice(r+st.length,a),d=`${n.slice(0,r)}${n.slice(a+it.length)}`.trimStart(),p=c.match(/JSON\.parse\((["'][\s\S]*?["'])\)/);if(!p)return{entryCode:d,modalHtml:"",modalStyles:"",modalWidth:"",modalHeight:""};try{const s=JSON.parse(JSON.parse(p[1]));return{entryCode:d,modalHtml:typeof s.html=="string"?s.html:"",modalStyles:typeof s.styles=="string"?s.styles:"",modalWidth:typeof s.width=="string"?s.width:"",modalHeight:typeof s.height=="string"?s.height:""}}catch{return{entryCode:d,modalHtml:"",modalStyles:"",modalWidth:"",modalHeight:""}}}function Me(n){let r;const a=n.settingsSchemaText.trim();if(a)try{r=JSON.parse(a)}catch{throw new TypeError("设置 Schema 不是有效的 JSON")}const c=Ee(n.permissions,n.networkHosts);return{kind:ae,packageVersion:ee,manifest:{manifestVersion:1,id:n.id.trim(),version:n.version.trim()||"0.0.0",apiVersion:1,source:"sandbox",metadata:{label:n.label.trim()||n.id.trim(),...n.description.trim()?{description:n.description.trim()}:{},icon:n.icon.trim()||"Code",category:n.category.trim()||"local"},sizes:{default:P(n.sizes.default),min:P(n.sizes.min),max:P(n.sizes.max)},renderer:{kind:"sandbox",entry:at},...r!==void 0?{settingsSchema:r}:{},...c.length?{capabilities:c}:{},compatibility:{targets:["web","extension"],minHostVersion:"1.0.0",mobileSupport:"full"},integrity:{sha256:"",assets:{}}},sandbox:{entry:at,scripts:{[at]:$e(n)},...n.styles.trim()?{styles:n.styles}:{},...n.html.trim()?{html:n.html}:{}}}}function ot(n,r=Date.now()){try{const a=Me(n),c=kt(a,r);return{ok:!0,wire:a,install:c.install}}catch(a){return{ok:!1,error:a instanceof Error?a.message:"组件包结构无效"}}}function wt(n){if(n.runtime!=="sandbox"||!n.manifest||!n.sandbox)return null;const r=n.manifest,a=n.sandbox.entry,{permissions:c,networkHosts:d}=Ie(r.capabilities),p=Ve(n.sandbox.scripts[a]||"");return{id:r.id,label:r.metadata.label,description:r.metadata.description||"",icon:r.metadata.icon||"Code",category:r.metadata.category||"local",version:r.version,sizes:{default:P(r.sizes.default),min:P(r.sizes.min),max:P(r.sizes.max)},permissions:c,networkHosts:d,entryCode:p.entryCode,styles:n.sandbox.styles||"",modalHtml:p.modalHtml,modalStyles:p.modalStyles,modalWidth:p.modalWidth||"760px",modalHeight:p.modalHeight||"620px",html:n.sandbox.html||"",settingsSchemaText:r.settingsSchema!==void 0?JSON.stringify(r.settingsSchema,null,2):""}}function Pe(n){const r=te(n);return r?JSON.stringify(r,null,2):null}const lt=`你是 VoidTab「组件设计器」的代码生成助手。VoidTab 的自定义组件运行在隔离的 iframe 沙箱里，使用固定的 VoidWidget 运行时 API。请根据用户描述生成一个完整、可直接运行、弹窗可正常交互的组件，并以严格 JSON 返回。

══════ 最重要（弹窗交互，违反必然无法交互）══════
A. 弹窗 HTML 里【绝对不能】写任何 JavaScript：禁止 <script>、onclick、oninput、onsubmit、href="javascript:" 等。这些会被 CSP 拦截、静默失效，是「弹窗点了没反应」的头号原因。
B. 弹窗与封面交互的【唯一】方式：在弹窗 HTML 的可点击元素上加属性 data-vt-action="动作名"，宿主会把点击转成对封面 modalEvent(ctx, event) 的回调。所有逻辑都写在封面 JS 的 modalEvent 里。
C. 只要弹窗里出现了任意 data-vt-action，封面就【必须】定义 modalEvent(ctx, event)，并为每一个动作名写处理分支；处理完数据后【必须】调用 VoidTabDesigner.updateModal(ctx, {...}) 重新渲染弹窗，否则界面不会更新。
D. 触发规则：
   - 普通按钮用 <button type="button" data-vt-action="x">，点击即触发。
   - 表单用 <form data-vt-action="save">，在提交时（含其内 <button type="submit">）触发，并把表单字段一起带出。
   - 【不要】给 input / select / textarea 本身加 data-vt-action（会被忽略，且会破坏原生时间/日期/下拉选择器）。
E. 回调参数 event = { name, data, source }：
   - name：动作名（data-vt-action 的值）。
   - data：离触发点最近的 <form> 的字段，键是 input/select/textarea 的 name，值是字符串；同名多值是数组；复选框勾选为 'on'、未勾选为 ''。
   - source.dataset：被点击元素的 data-* 集合（如删除某行时用 data-id="..."，在 event.source.dataset.id 读取）。
F. 弹窗 DOM 在每次 updateModal 时整体替换，因此【不要】缓存弹窗内的节点引用；每次都用数据重新生成完整 HTML。所有插入 HTML 的动态文本必须用 VoidTabDesigner.escapeHtml(value) 转义。

══════ 运行时契约 ══════
1. 封面 JS 必须调用 VoidWidget.define({ ... })，在 mount(ctx) 里创建 DOM 挂到 ctx.root。可选生命周期：update(ctx)、pause()、resume()、unmount()、modalEvent(ctx, event)。状态存在 this 上（如 this._state、this._timer）。有定时器/轮询必须在 pause 停、resume 启、unmount 清理。
2. ctx：ctx.root（封面根节点）、ctx.size.placement.w/h（当前格子尺寸，用于自适应 1×1 / 2×2 / 宽卡）、ctx.settings（实例设置对象）、ctx.storage.get/set/remove(key[,value])（异步、本实例私有、单值约 8KB，返回 Promise，用 await）、ctx.network.fetch(url,init)（需声明 network 能力且域名在白名单，仅 GET/HEAD）、ctx.openUrl(url)、ctx.copyText(text)、ctx.notify(title,options)、ctx.emit(name,data)。这些 Promise 调用都计入每分钟配额，不要放进每秒定时器。
3. 弹窗助手（系统已注入，禁止自行定义 VoidTabDesigner）：VoidTabDesigner.openModal(ctx, {title, html, width, height, scrollTarget}) 首次打开；VoidTabDesigner.updateModal(ctx, {title, html, scrollTarget}) 原地刷新（不重载、保留滚动）。强烈建议写一个 openDetail(ctx, self, updateOnly) 函数：updateOnly 为假走 openModal、为真走 updateModal；封面点击时 openDetail(ctx, this)，modalEvent 处理完 openDetail(ctx, this, true)。
4. 禁止外部依赖、import、远程脚本；全部逻辑写进封面 JS，只用普通 DOM API。
5. 样式适配主题变量：--vt-accent、--vt-text、--vt-muted、--vt-surface；封面根节点宽高 100%、已 border-box。

══════ 视觉设计（务必遵循，否则界面会很丑）══════
颜色：一律用主题变量派生，禁止写死纯黑/纯白或随意取色。
- 表面 = color-mix(in srgb, var(--vt-surface) 90%, transparent)
- 描边 = color-mix(in srgb, var(--vt-text) 12%, transparent)
- 次要文字 = var(--vt-muted)；强调/高亮 = var(--vt-accent)；正文 = var(--vt-text)
间距与圆角：卡片内边距 14–18px、元素间距 8–12px；圆角卡片 16–18px、控件 10–12px、标签 999px。
字号：标题 13–15px/900，正文 12–13px，辅助 11px；时间和数字加 font-variant-numeric: tabular-nums。
封面：根节点 width/height:100%，用 grid 布局，按 ctx.size.placement.w/h 自适应（小尺寸隐藏次要信息）；卡片用「渐变 + 半透明表面 + 1px 描边 + 轻微内阴影」，hover 要有细微反馈。务必填满卡片、不要留大片空白或裸文字。
弹窗：信息较多时优先「主从布局」——左列列表（约 240px）+ 右列详情（flex:1），窄屏（max-width:640px）塌成单列。列表项要有 hover 和选中态 .is-active；要有空状态占位；输入框/按钮统一风格，按钮分 主(实心 accent) / 次(描边) / 危险(红) 三类；标签用 chip 小圆角。
可直接采用的参考 CSS（按需改类名）：
.detail-layout{display:grid;grid-template-columns:240px minmax(0,1fr);gap:14px;height:100%;min-height:0}
.list{display:grid;gap:6px;align-content:start;overflow:auto;padding-right:2px}
.list-item{display:grid;gap:3px;padding:10px 12px;border-radius:12px;border:1px solid color-mix(in srgb,var(--vt-text) 12%,transparent);background:color-mix(in srgb,var(--vt-surface) 78%,transparent);cursor:pointer;text-align:left}
.list-item:hover{border-color:color-mix(in srgb,var(--vt-accent) 40%,transparent)}
.list-item.is-active{border-color:var(--vt-accent);background:color-mix(in srgb,var(--vt-accent) 12%,transparent)}
.pane{display:flex;flex-direction:column;gap:10px;min-width:0}
.input,.textarea{width:100%;border:1px solid color-mix(in srgb,var(--vt-text) 12%,transparent);border-radius:10px;background:color-mix(in srgb,var(--vt-surface) 82%,transparent);color:var(--vt-text);font:inherit;outline:none}
.input{height:34px;padding:0 10px}.textarea{min-height:160px;padding:10px;resize:vertical;line-height:1.6}
.input:focus,.textarea:focus{border-color:var(--vt-accent)}
.btn{height:34px;padding:0 14px;border-radius:10px;font-weight:800;cursor:pointer;border:1px solid color-mix(in srgb,var(--vt-text) 12%,transparent);background:color-mix(in srgb,var(--vt-surface) 80%,transparent);color:var(--vt-text)}
.btn.primary{border-color:transparent;background:var(--vt-accent);color:#fff}
.btn.danger{border-color:color-mix(in srgb,#ef4444 40%,transparent);color:#ef4444}
.chip{display:inline-flex;align-items:center;padding:3px 9px;border-radius:999px;border:1px solid color-mix(in srgb,var(--vt-text) 12%,transparent);background:color-mix(in srgb,var(--vt-surface) 74%,transparent);font-size:11px;color:var(--vt-muted)}
.empty{display:grid;place-items:center;height:100%;color:var(--vt-muted);font-size:12px}
@media(max-width:640px){.detail-layout{grid-template-columns:1fr}}

══════ 完整可运行示例（必须照此结构生成，尤其是 modalEvent + openDetail 的闭环）══════
// 一个可增删的「今日待办」：封面显示数量，点击打开弹窗增删。
VoidWidget.define({
  async mount(ctx) {
    this._root = document.createElement('button');
    this._root.type = 'button';
    this._root.className = 'todo-card';
    ctx.root.appendChild(this._root);
    this._items = await loadItems(ctx);
    renderCover(this);
    this._root.addEventListener('click', () => openDetail(ctx, this));
  },
  async modalEvent(ctx, event) {
    if (event.name === 'add') {
      const text = readValue(event.data, 'newText');
      if (text) this._items.push({ id: 'i' + Date.now(), text: text });
    } else if (event.name === 'delete') {
      const id = event.source && event.source.dataset ? event.source.dataset.id : '';
      this._items = this._items.filter((it) => it.id !== id);
    }
    await saveItems(ctx, this._items);
    renderCover(this);
    openDetail(ctx, this, true); // 关键：处理完用 updateModal 原地刷新弹窗
  },
});

function readValue(data, key) {
  const v = data && data[key];
  return String(Array.isArray(v) ? v[0] : (v || '')).trim();
}
async function loadItems(ctx) {
  const saved = await ctx.storage.get('items');
  return Array.isArray(saved) ? saved : [];
}
async function saveItems(ctx, items) {
  try { await ctx.storage.set('items', items); } catch (e) {}
}
function renderCover(self) {
  self._root.textContent = '待办 ' + self._items.length + ' 项';
}
function openDetail(ctx, self, updateOnly) {
  const esc = VoidTabDesigner.escapeHtml;
  const rows = self._items.map((it) =>
    '<li class="row"><span>' + esc(it.text) + '</span>' +
    '<button type="button" data-vt-action="delete" data-id="' + esc(it.id) + '">删除</button></li>'
  ).join('') || '<li class="empty">还没有待办</li>';
  const html =
    '<main class="todo-detail">' +
      '<ul class="list">' + rows + '</ul>' +
      '<form class="add" data-vt-action="add">' +
        '<input name="newText" placeholder="新增一项待办">' +
        '<button type="submit">添加</button>' +
      '</form>' +
    '</main>';
  const payload = { title: '今日待办', html: html };
  return updateOnly ? VoidTabDesigner.updateModal(ctx, payload) : VoidTabDesigner.openModal(ctx, payload);
}

══════ 生成前自检（务必满足）══════
- 弹窗里每个可交互元素都用 data-vt-action，没有任何内联 JS / <script>。
- modalEvent 覆盖了弹窗里出现的每一个 data-vt-action 动作名。
- 每个分支改完数据后都调用了 updateModal（或经 openDetail(..., true)）刷新。
- 需要持久化就声明 storage 并用 await ctx.storage 读写。
- entryCode 是合法的 JS；返回的整体是合法 JSON（字符串里的换行、引号、反斜杠都正确转义）。

══════ 输出格式 ══════
只返回一个 JSON 对象（可放在 \`\`\`json 代码块中），不要输出任何解释文字。字段：
{
  "label": "组件名（中文）",
  "description": "一句话描述",
  "icon": "Phosphor 图标名，如 Clock / ListChecks / ChartLine",
  "entryCode": "封面 JS，含 VoidWidget.define(...) 与 modalEvent；不要包含 VoidTabDesigner 的定义",
  "styles": "封面 CSS",
  "modalHtml": "弹窗默认 HTML（静态示例即可，运行时由 openModal/updateModal 覆盖；同样禁止内联 JS）",
  "modalStyles": "弹窗 CSS",
  "modalWidth": "如 760px 或 80vw",
  "modalHeight": "如 620px 或 72vh",
  "permissions": ["storage"],
  "networkHosts": [],
  "settingsSchema": null
}
permissions 仅可从 ["storage","network","openExternal","clipboard.write","notifications"] 中选取，按需声明，不需要就给 []。settingsSchema 为可选 JSON Schema 对象，不需要就给 null。`;function ct(n,r){const a=n.trim()||"一个实用的小组件",c=r.sizes.default,d=r.sizes.min;return`请为 VoidTab 设计一个组件。需求：${a}

约束：
- 组件 ID 固定为「${r.id.trim()||"my.widget"}」，请勿更改。
- 默认尺寸 ${c.w}×${c.h}，最小 ${d.w}×${d.h}，请让封面在该范围内自适应。
- 界面用中文，视觉精致，配色走主题变量。
- 提供配套弹窗用于查看/编辑数据：弹窗里所有交互都用 data-vt-action（禁止内联 JS / <script>），并在封面 modalEvent 里为每个动作写处理分支，处理后用 updateModal 刷新弹窗（参考系统示例的 openDetail 闭环）。
- 若需要持久化数据，请声明 storage 能力并用 await ctx.storage 读写。`}function Oe(n,r){return`${lt}

———— 需求 ————
${ct(n,r)}`}function Le(n,r){return[{id:"system",label:"系统提示词（运行时契约）",text:lt},{id:"request",label:"需求提示词",text:ct(n,r)},{id:"full",label:"完整提示词（粘贴到外部 AI）",text:Oe(n,r)}]}const je=new Set(["storage","network","openExternal","clipboard.write","notifications"]);function Re(n){const r=n.match(/```(?:json)?\s*([\s\S]*?)```/i),a=(r?r[1]:n).trim(),c=a.indexOf("{"),d=a.lastIndexOf("}");return c<0||d<=c?null:a.slice(c,d+1)}function Je(n){const r=Re(String(n||""));if(!r)return{ok:!1,error:"未在回复中找到 JSON 内容"};let a;try{a=JSON.parse(r)}catch{return{ok:!1,error:"AI 返回的 JSON 无法解析，请检查格式或重试"}}if(!a||typeof a!="object"||Array.isArray(a))return{ok:!1,error:"AI 返回的不是一个对象"};const c=p=>typeof p=="string"?p:"",d={};return typeof a.label=="string"&&a.label.trim()&&(d.label=a.label.trim().slice(0,60)),typeof a.description=="string"&&(d.description=a.description.trim().slice(0,200)),typeof a.icon=="string"&&a.icon.trim()&&(d.icon=a.icon.trim().slice(0,40)),typeof a.entryCode=="string"&&(d.entryCode=a.entryCode),typeof a.styles=="string"&&(d.styles=a.styles),typeof a.html=="string"&&(d.html=a.html),typeof a.modalHtml=="string"&&(d.modalHtml=a.modalHtml),typeof a.modalStyles=="string"&&(d.modalStyles=a.modalStyles),typeof a.modalWidth=="string"&&a.modalWidth.trim()&&(d.modalWidth=a.modalWidth.trim()),typeof a.modalHeight=="string"&&a.modalHeight.trim()&&(d.modalHeight=a.modalHeight.trim()),Array.isArray(a.permissions)&&(d.permissions=a.permissions.map(p=>c(p).trim()).filter(p=>je.has(p))),Array.isArray(a.networkHosts)&&(d.networkHosts=a.networkHosts.map(p=>c(p).trim()).filter(Boolean)),a.settingsSchema&&typeof a.settingsSchema=="object"&&!Array.isArray(a.settingsSchema)&&(d.settingsSchemaText=JSON.stringify(a.settingsSchema,null,2)),!d.entryCode||!d.entryCode.includes("VoidWidget.define")?{ok:!1,error:"AI 回复缺少有效的封面 JS（需包含 VoidWidget.define）"}:{ok:!0,draftPatch:d}}function Ue(n,r){return{...n,...r,id:n.id,version:n.version,category:n.category,sizes:{default:P(n.sizes.default),min:P(n.sizes.min),max:P(n.sizes.max)}}}const dt=`:root{
  --sample-accent:var(--vt-accent,#3b82f6);
  --sample-text:var(--vt-text,#f8fafc);
  --sample-muted:var(--vt-muted,rgba(248,250,252,.66));
  --sample-surface:var(--vt-surface,rgba(255,255,255,.08));
  --sample-line:color-mix(in srgb,var(--sample-text) 13%,transparent);
}
:is(.focus-clock,.habit-card,.net-card){
  position:relative;isolation:isolate;overflow:hidden;
  width:100%;height:100%;box-sizing:border-box;border:1px solid var(--sample-line);
  border-radius:inherit;color:var(--sample-text);cursor:pointer;text-align:left;
  background:
    linear-gradient(135deg,color-mix(in srgb,var(--sample-accent) 12%,transparent),transparent 56%),
    color-mix(in srgb,var(--sample-surface) 92%,transparent);
  box-shadow:inset 0 1px 0 color-mix(in srgb,#fff 16%,transparent);
  transition:transform .16s ease,border-color .16s ease,background .16s ease;
}
:is(.focus-clock,.habit-card,.net-card)::before{
  content:"";position:absolute;inset:0;z-index:-1;
  background:linear-gradient(90deg,color-mix(in srgb,var(--sample-accent) 13%,transparent),transparent 34%);
  opacity:.9;mask-image:linear-gradient(135deg,#000,transparent 72%);
}
:is(.focus-clock,.habit-card,.net-card):hover{border-color:color-mix(in srgb,var(--sample-accent) 45%,transparent)}
:is(.focus-clock,.habit-card,.net-card):active{transform:scale(.985)}
`,pt=`.modal-card{
  --sample-accent:var(--vt-accent,#3b82f6);
  --sample-text:var(--vt-text,#f8fafc);
  --sample-muted:var(--vt-muted,rgba(248,250,252,.66));
  --sample-surface:var(--vt-surface,rgba(255,255,255,.08));
  --sample-line:color-mix(in srgb,var(--sample-text) 13%,transparent);
  min-height:100%;padding:22px;color:var(--sample-text);
  background:
    linear-gradient(135deg,color-mix(in srgb,var(--sample-accent) 9%,transparent),transparent 54%),
    color-mix(in srgb,var(--sample-surface) 94%,transparent);
}
.sample-hero,.modal-card>header{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;padding:18px;border:1px solid var(--sample-line);border-radius:18px;background:color-mix(in srgb,var(--sample-surface) 82%,transparent)}
.sample-hero>div,.modal-card>header>div{min-width:0}
.modal-card header span{display:block;font-size:11px;line-height:1.2;font-weight:950;letter-spacing:0;color:var(--sample-accent)}
.modal-card h1{margin:8px 0 7px;font-size:clamp(26px,7vw,44px);line-height:1;font-weight:950;letter-spacing:0;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
.modal-card p{max-width:64ch;margin:0;color:var(--sample-muted)}
.hero-badge,.section-badge{flex:0 0 auto;display:inline-flex;align-items:center;justify-content:center;min-width:52px;height:32px;padding:0 10px;border-radius:11px;border:1px solid color-mix(in srgb,var(--sample-accent) 34%,transparent);background:color-mix(in srgb,var(--sample-accent) 10%,transparent);color:var(--sample-accent);font-style:normal;font-size:12px;font-weight:950}
.status-strip{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:12px;padding:14px;border-radius:16px;background:color-mix(in srgb,var(--sample-surface) 78%,transparent);border:1px solid var(--sample-line)}
.status-strip b,.status-strip span{display:block}.status-strip b{font-size:16px}.status-strip span{margin-top:3px;font-size:12px;color:var(--sample-muted)}
.sample-section{margin-top:14px;padding:16px;border-radius:18px;border:1px solid var(--sample-line);background:color-mix(in srgb,var(--sample-surface) 74%,transparent)}
.section-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}.section-head h2{margin:0;font-size:14px;line-height:1.2}.section-head span{font-size:11px;font-weight:900;color:var(--sample-muted)}
.metric-grid,.habit-stats,.net-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px}
.metric-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
.metric-grid article,.habit-stats article,.net-grid article{min-width:0;padding:14px;border-radius:15px;background:color-mix(in srgb,var(--sample-surface) 76%,transparent);border:1px solid var(--sample-line)}
.metric-grid span,.habit-stats span,.net-grid span{display:block;font-size:11px;font-weight:850;color:var(--sample-muted)}
.metric-grid b,.habit-stats b,.net-grid b{display:block;margin-top:5px;font-size:clamp(16px,4vw,24px);line-height:1.1;font-weight:950;overflow-wrap:anywhere}
.metric-grid em,.habit-meter{display:block;height:8px;margin-top:11px;border-radius:999px;background:color-mix(in srgb,var(--sample-text) 10%,transparent);overflow:hidden}
.metric-grid i,.habit-meter b{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--sample-accent),color-mix(in srgb,var(--sample-accent) 42%,#fff))}
.editable-list,.field-list{display:grid;gap:8px}
.edit-row{display:grid;grid-template-columns:58px minmax(80px,.75fr) minmax(120px,1.25fr);gap:8px;align-items:center;padding:8px;border-radius:13px;border:1px solid var(--sample-line);background:color-mix(in srgb,var(--sample-surface) 70%,transparent)}
.edit-row.is-active{border-color:color-mix(in srgb,var(--sample-accent) 42%,transparent);background:color-mix(in srgb,var(--sample-accent) 9%,transparent)}
.row-time{font-size:12px;font-weight:950;color:var(--sample-accent);font-variant-numeric:tabular-nums}
.inline-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:12px}
.inline-field{display:grid;gap:6px}.inline-field span{font-size:11px;font-weight:900;color:var(--sample-muted)}
input,textarea{width:100%;min-width:0;border:1px solid var(--sample-line);border-radius:11px;background:color-mix(in srgb,var(--sample-surface) 82%,transparent);color:var(--sample-text);font:inherit;font-size:13px;outline:none}
input{height:34px;padding:0 10px}textarea{min-height:78px;padding:9px 10px;resize:vertical}
input:focus,textarea:focus{border-color:color-mix(in srgb,var(--sample-accent) 58%,transparent);box-shadow:0 0 0 3px color-mix(in srgb,var(--sample-accent) 13%,transparent)}
.field-row{display:grid;grid-template-columns:130px minmax(0,1fr);gap:12px;align-items:start;padding:10px 0;border-bottom:1px solid var(--sample-line)}.field-row:last-child{border-bottom:0}
.field-row span{font-size:11px;font-weight:900;color:var(--sample-muted)}.field-row b{font-size:13px;line-height:1.35;overflow-wrap:anywhere}
.tag-row{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}.tag-row span{padding:6px 9px;border-radius:999px;border:1px solid var(--sample-line);background:color-mix(in srgb,var(--sample-surface) 75%,transparent);font-size:11px;font-weight:850;color:var(--sample-muted)}
.habit-meter{margin-top:14px}.habit-note{margin-top:14px!important;font-size:12px}
@media(max-width:560px){.sample-hero,.modal-card>header{display:grid}.metric-grid,.habit-stats,.net-grid,.inline-fields{grid-template-columns:1fr}.edit-row,.field-row{grid-template-columns:1fr}.hero-badge{justify-content:flex-start;width:max-content}}
`,We=`// 时间看板：显示时间、日期、下一项闹钟，并支持在详情中维护今日计划。
const PLAN_KEY = 'time-board-plan-v2';

VoidWidget.define({
  async mount(ctx) {
    const root = document.createElement('button');
    root.className = 'focus-clock time-card';
    root.type = 'button';
    root.innerHTML =
      '<div class="time-head"><span class="date-line"></span><b class="weekday-pill"></b></div>' +
      '<div class="time-main"><strong class="clock-time"></strong><span class="clock-seconds"></span></div>' +
      '<div class="next-alarm"><span></span><b></b><small></small></div>' +
      '<div class="clock-band"><span></span><b><i></i></b></div>';
    ctx.root.appendChild(root);

    const state = {
      root,
      plan: await loadPlan(ctx),
      lastAlertKey: '',
      paused: false,
    };
    this._state = state;
    this._render = () => render(ctx, state);

    root.addEventListener('click', () => openDetail(ctx, state));
    this._render();
    this._timer = setInterval(this._render, 1000);
  },
  pause() {
    if (this._timer) clearInterval(this._timer);
    this._timer = null;
    if (this._state) this._state.paused = true;
  },
  resume() {
    if (!this._render || this._timer) return;
    if (this._state) this._state.paused = false;
    this._render();
    this._timer = setInterval(this._render, 1000);
  },
  unmount() {
    if (this._timer) clearInterval(this._timer);
    this._timer = null;
  },
  async modalEvent(ctx, event) {
    const state = this._state || {plan: defaultPlan(), root: null, lastAlertKey: ''};
    if (event.name === 'save-time-plan') {
      state.plan = readPlanFromForm(event.data);
      await savePlan(ctx, state.plan);
      render(ctx, state);
      openDetail(ctx, state, '计划已保存，封面会显示最近一项', true, '[data-vt-section="plan-list"]');
      return;
    }
    if (event.name === 'add-time-plan') {
      state.plan = readPlanFromForm(event.data, normalizePlan(state.plan));
      await savePlan(ctx, state.plan);
      render(ctx, state);
      openDetail(ctx, state, '已添加一项计划', true, '[data-vt-section="add-plan"]');
      return;
    }
    if (event.name === 'delete-time-plan') {
      const index = Number(event.source && event.source.dataset ? event.source.dataset.index : -1);
      const next = readPlanFromForm(event.data, normalizePlan(state.plan));
      if (Number.isInteger(index) && index >= 0) next.splice(index, 1);
      state.plan = normalizePlan(next);
      await savePlan(ctx, state.plan);
      render(ctx, state);
      openDetail(ctx, state, '已删除该计划', true, '[data-vt-section="plan-list"]');
      return;
    }
    if (event.name === 'reset-time-plan') {
      state.plan = defaultPlan();
      await savePlan(ctx, state.plan);
      render(ctx, state);
      openDetail(ctx, state, '已恢复示例闹钟和计划', true, '[data-vt-section="plan-list"]');
    }
  },
});

function getPlacement(ctx) {
  return ctx.size && ctx.size.placement ? ctx.size.placement : {w: 2, h: 2};
}

function getPanelTitle(ctx) {
  const value = ctx.settings && typeof ctx.settings.panelTitle === 'string' ? ctx.settings.panelTitle.trim() : '';
  return value || '时间看板';
}

function defaultPlan() {
  return [
    {time: '07:30', title: '起床', note: '洗漱、喝水、查看今天安排', enabled: true},
    {time: '09:30', title: '开始工作', note: '处理最重要的一件事', enabled: true},
    {time: '12:20', title: '午休', note: '离开屏幕，补充能量', enabled: true},
    {time: '18:30', title: '晚间计划', note: '运动、采购或家庭事项', enabled: true},
  ];
}

function normalizeTime(value) {
  const match = String(value || '').trim().match(/^(\\d{1,2}):(\\d{2})$/);
  if (!match) return '';
  const hour = Math.max(0, Math.min(23, Number(match[1]) || 0));
  const minute = Math.max(0, Math.min(59, Number(match[2]) || 0));
  return String(hour).padStart(2, '0') + ':' + String(minute).padStart(2, '0');
}

function normalizePlan(items) {
  const list = Array.isArray(items) ? items : [];
  return list.map((item) => ({
    time: normalizeTime(item && item.time),
    title: String(item && item.title || '').trim().slice(0, 36),
    note: String(item && item.note || '').trim().slice(0, 90),
    enabled: item ? item.enabled !== false : true,
  })).filter((item) => item.time && item.title).slice(0, 8).sort((a, b) => a.time.localeCompare(b.time));
}

async function loadPlan(ctx) {
  try {
    const saved = await ctx.storage.get(PLAN_KEY);
    const normalized = normalizePlan(saved);
    if (normalized.length) return normalized;
  } catch (e) {}
  return defaultPlan();
}

async function savePlan(ctx, plan) {
  try {
    await ctx.storage.set(PLAN_KEY, normalizePlan(plan));
  } catch (e) {}
}

function readFormValue(data, key) {
  const value = data && data[key];
  return Array.isArray(value) ? String(value[0] || '') : String(value || '');
}

function readPlanFromForm(data, fallback) {
  const plan = [];
  for (let index = 0; index < 8; index += 1) {
    const time = normalizeTime(readFormValue(data, 'time' + index));
    const title = readFormValue(data, 'title' + index).trim();
    const note = readFormValue(data, 'note' + index).trim();
    if (time && title) {
      plan.push({time, title: title.slice(0, 36), note: note.slice(0, 90), enabled: readFormValue(data, 'enabled' + index) === 'on'});
    }
  }
  const newTime = normalizeTime(readFormValue(data, 'newTime'));
  const newTitle = readFormValue(data, 'newTitle').trim();
  if (newTime && newTitle) {
    plan.push({time: newTime, title: newTitle.slice(0, 36), note: readFormValue(data, 'newNote').trim().slice(0, 90), enabled: true});
  }
  const normalized = normalizePlan(plan);
  const fallbackPlan = normalizePlan(fallback);
  return normalized.length ? normalized : (fallbackPlan.length ? fallbackPlan : defaultPlan());
}

function minuteOf(time) {
  const parts = String(time || '00:00').split(':').map(Number);
  return (parts[0] || 0) * 60 + (parts[1] || 0);
}

function getNextAlarm(now, plan) {
  const enabled = normalizePlan(plan).filter((item) => item.enabled !== false);
  if (!enabled.length) return null;
  const current = now.getHours() * 60 + now.getMinutes();
  for (const item of enabled) {
    const diff = minuteOf(item.time) - current;
    if (diff >= 0) return {item, diff, tomorrow: false};
  }
  return {item: enabled[0], diff: 1440 - current + minuteOf(enabled[0].time), tomorrow: true};
}

function formatDiff(minutes) {
  if (minutes <= 0) return '现在';
  const hour = Math.floor(minutes / 60);
  const minute = minutes % 60;
  if (!hour) return minute + ' 分钟后';
  return hour + ' 小时 ' + String(minute).padStart(2, '0') + ' 分钟后';
}

function dayProgress(now) {
  return Math.round((now.getHours() * 60 + now.getMinutes()) / 1440 * 100);
}

function weekProgress(now) {
  const day = now.getDay() || 7;
  return Math.min(100, Math.round(((day - 1) * 1440 + now.getHours() * 60 + now.getMinutes()) / (7 * 1440) * 100));
}

function render(ctx, state) {
  if (!state.root) return;
  const now = new Date();
  const placement = getPlacement(ctx);
  const compact = placement.w <= 1 || placement.h <= 1;
  const wide = placement.w >= 3;
  const next = getNextAlarm(now, state.plan);
  const progress = dayProgress(now);

  state.root.classList.toggle('is-compact', compact);
  state.root.classList.toggle('is-wide', wide);
  state.root.querySelector('.date-line').textContent = now.toLocaleDateString('zh-CN', {month: 'long', day: 'numeric'});
  state.root.querySelector('.weekday-pill').textContent = now.toLocaleDateString('zh-CN', {weekday: 'short'});
  state.root.querySelector('.clock-time').textContent = now.toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'});
  state.root.querySelector('.clock-seconds').textContent = now.toLocaleTimeString('zh-CN', {second: '2-digit'}).replace(/\\D/g, '');
  state.root.querySelector('.next-alarm span').textContent = next ? (next.tomorrow ? '明天提醒' : '下一项') : '今日计划';
  state.root.querySelector('.next-alarm b').textContent = next ? next.item.time + ' · ' + next.item.title : '暂无启用提醒';
  state.root.querySelector('.next-alarm small').textContent = next ? formatDiff(next.diff) + (next.item.note ? ' / ' + next.item.note : '') : '打开详情添加闹钟';
  state.root.querySelector('.clock-band span').textContent = '今日 ' + progress + '%';
  state.root.querySelector('.clock-band i').style.width = progress + '%';

  if (!state.paused) checkDueNotification(ctx, state, now, next);
}

function checkDueNotification(ctx, state, now, next) {
  if (!next || next.tomorrow || next.diff !== 0 || now.getSeconds() > 3) return;
  const key = now.toLocaleDateString('zh-CN') + ':' + next.item.time + ':' + next.item.title;
  if (state.lastAlertKey === key) return;
  state.lastAlertKey = key;
  ctx.notify(next.item.title, {body: next.item.note || '时间到了'}).catch(() => {});
}

function buildAlarmRows(plan) {
  const esc = VoidTabDesigner.escapeHtml;
  return normalizePlan(plan).map((item, index) =>
    '<label class="alarm-row">' +
      '<input class="alarm-check" type="checkbox" name="enabled' + index + '" ' + (item.enabled === false ? '' : 'checked') + '>' +
      '<input type="time" name="time' + index + '" value="' + esc(item.time) + '">' +
      '<input name="title' + index + '" value="' + esc(item.title) + '" placeholder="标题">' +
      '<input name="note' + index + '" value="' + esc(item.note) + '" placeholder="备注">' +
      '<button type="button" class="row-danger" data-vt-action="delete-time-plan" data-index="' + index + '">删除</button>' +
    '</label>'
  ).join('');
}

function openDetail(ctx, state, notice, updateOnly, scrollTarget) {
  const now = new Date();
  const next = getNextAlarm(now, state.plan);
  const esc = VoidTabDesigner.escapeHtml;
  const title = getPanelTitle(ctx);
  const time = now.toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit', second: '2-digit'});
  const date = now.toLocaleDateString('zh-CN', {weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'});
  const html =
    '<main class="modal-card time-detail">' +
      '<header class="sample-hero time-hero"><div><span>' + esc(title) + '</span><h1>' + esc(time) + '</h1><p>' + esc(date) + '</p></div><i class="hero-badge">闹钟</i></header>' +
      '<section class="time-dock">' +
        '<article><span>下一项</span><b>' + esc(next ? next.item.time + ' · ' + next.item.title : '暂无启用提醒') + '</b><small>' + esc(next ? formatDiff(next.diff) : '添加计划后显示倒计时') + '</small></article>' +
        '<article><span>今日</span><b>' + dayProgress(now) + '%</b><small>一天进度</small></article>' +
        '<article><span>本周</span><b>' + weekProgress(now) + '%</b><small>周进度</small></article>' +
      '</section>' +
      '<form class="alarm-form" data-vt-action="save-time-plan">' +
        '<section class="sample-section" data-vt-section="plan-list"><div class="section-head"><h2>闹钟和计划</h2><span>最多 8 项，保存在本实例</span></div>' + (notice ? '<p class="section-notice">' + esc(notice) + '</p>' : '') + '<div class="alarm-board">' + buildAlarmRows(state.plan) + '</div></section>' +
        '<section class="sample-section add-alarm" data-vt-section="add-plan"><div class="section-head"><h2>新增一项</h2><span>立即添加到本实例</span></div><div class="alarm-row new-row"><span></span><input type="time" name="newTime"><input name="newTitle" placeholder="例如：喝水 / 会议 / 取快递"><input name="newNote" placeholder="备注"><button type="button" class="row-add" data-vt-action="add-time-plan">添加</button></div></section>' +
        '<div class="modal-actions"><button type="submit" class="primary-action" data-vt-action="save-time-plan">保存全部</button><button type="button" class="secondary-action" data-vt-action="reset-time-plan">恢复示例</button></div>' +
      '</form>' +
      '<p class="habit-note">提示：封面会显示最近一项倒计时；到点时会尝试发送本地通知，正式桌面实例需授权通知能力。</p>' +
    '</main>';
  const payload = {title: title, html: html, scrollTarget: scrollTarget || ''};
  return updateOnly ? VoidTabDesigner.updateModal(ctx, payload) : VoidTabDesigner.openModal(ctx, payload);
}`,qe=`${dt}
.time-card{
  padding:16px;border:0;
  display:grid;grid-template-rows:auto 1fr auto auto;gap:11px;
}
.time-head,.clock-band{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:11px;font-weight:850;color:var(--sample-muted)}
.date-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.weekday-pill{display:inline-flex;align-items:center;justify-content:center;min-width:36px;height:24px;padding:0 8px;border-radius:999px;background:color-mix(in srgb,var(--sample-accent) 14%,transparent);color:var(--sample-accent);font-size:11px;font-weight:950}
.time-main{display:flex;align-items:flex-end;gap:8px;min-width:0}
.clock-time{font-size:clamp(40px,19cqw,82px);line-height:.88;font-weight:950;letter-spacing:0;font-variant-numeric:tabular-nums}
.clock-seconds{margin-bottom:5px;font-size:clamp(14px,5cqw,24px);line-height:1;font-weight:950;color:var(--sample-accent);font-variant-numeric:tabular-nums}
.next-alarm{display:grid;gap:3px;min-width:0;padding:10px 11px;border-radius:15px;background:color-mix(in srgb,var(--sample-surface) 76%,transparent);border:1px solid var(--sample-line)}
.next-alarm span{font-size:10px;font-weight:950;color:var(--sample-accent)}
.next-alarm b{font-size:13px;line-height:1.18;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.next-alarm small{font-size:11px;line-height:1.22;color:var(--sample-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.clock-band{gap:8px}
.clock-band b{height:7px;flex:1;border-radius:999px;background:color-mix(in srgb,var(--sample-text) 11%,transparent);overflow:hidden}
.clock-band i{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--sample-accent),color-mix(in srgb,var(--sample-accent) 36%,#fff));transition:width .2s ease}
.time-card.is-compact{place-items:center;text-align:center;padding:12px;grid-template-rows:auto auto auto}
.time-card.is-compact .time-head,.time-card.is-compact .next-alarm small,.time-card.is-compact .clock-band{display:none}
.time-card.is-compact .time-main{align-items:baseline}
.time-card.is-compact .clock-time{font-size:clamp(30px,22cqw,54px)}
.time-card.is-wide{grid-template-columns:1.2fr .8fr;grid-template-rows:auto 1fr auto}
.time-card.is-wide .time-head,.time-card.is-wide .time-main,.time-card.is-wide .clock-band{grid-column:1}
.time-card.is-wide .next-alarm{grid-column:2;grid-row:1 / span 3;align-self:stretch;align-content:center}
}`,Ge=`<main class="modal-card time-detail">
  <header class="sample-hero time-hero">
    <div>
      <span>时间看板</span>
      <h1>09:41:26</h1>
      <p>2026年6月27日 星期六</p>
    </div>
    <i class="hero-badge">闹钟</i>
  </header>
  <section class="time-dock">
    <article><span>下一项</span><b>09:30 · 开始工作</b><small>1 小时 12 分钟后</small></article>
    <article><span>今日</span><b>41%</b><small>一天进度</small></article>
    <article><span>本周</span><b>72%</b><small>周进度</small></article>
  </section>
  <form class="alarm-form">
    <section class="sample-section"><div class="section-head"><h2>闹钟和计划</h2><span>保存在本实例</span></div>
      <div class="alarm-board">
        <label class="alarm-row"><input class="alarm-check" type="checkbox" checked><input type="time" value="07:30"><input value="起床"><input value="洗漱、喝水、查看今天安排"><button type="button" class="row-danger">删除</button></label>
        <label class="alarm-row"><input class="alarm-check" type="checkbox" checked><input type="time" value="09:30"><input value="开始工作"><input value="处理最重要的一件事"><button type="button" class="row-danger">删除</button></label>
        <label class="alarm-row"><input class="alarm-check" type="checkbox" checked><input type="time" value="18:30"><input value="晚间计划"><input value="运动、采购或家庭事项"><button type="button" class="row-danger">删除</button></label>
      </div>
    </section>
    <section class="sample-section add-alarm"><div class="section-head"><h2>新增一项</h2><span>立即添加到本实例</span></div><div class="alarm-row new-row"><span></span><input type="time"><input placeholder="例如：会议"><input placeholder="备注"><button type="button" class="row-add">添加</button></div></section>
    <div class="modal-actions"><button type="button" class="primary-action">保存全部</button><button type="button" class="secondary-action">恢复示例</button></div>
  </form>
</main>`,Ke=`${pt}
.time-dock{display:grid;grid-template-columns:1.35fr .75fr .75fr;gap:10px;margin-top:14px}
.time-dock article{min-width:0;padding:15px;border-radius:16px;border:1px solid var(--sample-line);background:color-mix(in srgb,var(--sample-surface) 76%,transparent)}
.time-dock span{display:block;font-size:11px;font-weight:900;color:var(--sample-muted)}
.time-dock b{display:block;margin-top:6px;font-size:clamp(18px,4vw,28px);line-height:1.1;font-weight:950;overflow-wrap:anywhere}
.time-dock small{display:block;margin-top:5px;font-size:12px;color:var(--sample-muted)}
.section-notice{margin:0 0 10px!important;padding:8px 10px;border-radius:12px;border:1px solid color-mix(in srgb,var(--sample-accent) 30%,transparent);background:color-mix(in srgb,var(--sample-accent) 9%,transparent);color:var(--sample-accent)!important;font-size:12px;font-weight:850}
.alarm-form{margin-top:14px}.alarm-board{display:grid;gap:8px}
.alarm-row{display:grid;grid-template-columns:26px 96px minmax(110px,.75fr) minmax(140px,1.1fr) auto;gap:8px;align-items:center;padding:8px;border-radius:14px;border:1px solid var(--sample-line);background:color-mix(in srgb,var(--sample-surface) 70%,transparent)}
.alarm-check{width:18px;height:18px;accent-color:var(--sample-accent)}
.alarm-row input[type=time]{font-variant-numeric:tabular-nums}
.new-row span{width:18px;height:18px;border-radius:999px;background:color-mix(in srgb,var(--sample-accent) 16%,transparent)}
.row-danger,.row-add{height:32px;padding:0 10px;border-radius:10px;border:1px solid var(--sample-line);font-size:12px;font-weight:950;background:color-mix(in srgb,var(--sample-surface) 78%,transparent);color:var(--sample-text)}
.row-danger{border-color:color-mix(in srgb,#ef4444 36%,transparent);color:#ef4444}
.row-add{border-color:color-mix(in srgb,var(--sample-accent) 44%,transparent);color:var(--sample-accent)}
.modal-actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:14px}
.primary-action,.secondary-action{height:36px;padding:0 14px;border-radius:12px;border:1px solid var(--sample-line);font-size:13px;font-weight:950;color:var(--sample-text);background:color-mix(in srgb,var(--sample-surface) 80%,transparent)}
.primary-action{border-color:color-mix(in srgb,var(--sample-accent) 44%,transparent);background:var(--sample-accent);color:#fff}
@media(max-width:640px){.time-dock{grid-template-columns:1fr}.alarm-row{grid-template-columns:24px 1fr}.alarm-row input:nth-child(4),.alarm-row button{grid-column:2}}
`,Be=JSON.stringify({type:"object",additionalProperties:!0,properties:{panelTitle:{type:"string",title:"看板标题",default:"时间看板",maxLength:24},note:{type:"string",title:"说明",default:"点击卡片可维护闹钟和计划；到点时会尝试发送本地通知。",maxLength:160}}},null,2),Fe=`// 习惯进度：点击封面记录一次，详情里可调整目标、撤销或重置今天。
const HABIT_KEY = 'habit-progress-v2';

VoidWidget.define({
  async mount(ctx) {
    const button = document.createElement('button');
    button.className = 'habit-card';
    button.type = 'button';
    ctx.root.appendChild(button);

    const state = {button, data: await loadHabit(ctx)};
    this._state = state;
    paint(ctx, state);

    button.addEventListener('click', async () => {
      ensureToday(state.data);
      addHabitRecord(state.data, '');
      state.data.updatedAt = new Date().toISOString();
      await saveHabit(ctx, state.data);
      paint(ctx, state);
      openDetail(ctx, state);
    });
  },
  async modalEvent(ctx, event) {
    const state = this._state;
    if (!state) return;
    ensureToday(state.data);
    if (event.name === 'save-habit-settings') {
      state.data.title = readText(event.data, 'habitTitle', state.data.title).slice(0, 24);
      state.data.target = clampNumber(readText(event.data, 'target', state.data.target), 1, 12);
      state.data.minutes = clampNumber(readText(event.data, 'minutes', state.data.minutes), 5, 180);
      state.data.count = Math.min(state.data.count, state.data.target);
      state.data.updatedAt = new Date().toISOString();
      await saveHabit(ctx, state.data);
      paint(ctx, state);
      openDetail(ctx, state, '设置已保存', true, '[data-vt-section="habit-settings"]');
      return;
    }
    if (event.name === 'add-habit-record') {
      addHabitRecord(state.data, readText(event.data, 'newRecordNote', ''));
      await saveHabit(ctx, state.data);
      paint(ctx, state);
      openDetail(ctx, state, '已新增一条记录', true, '[data-vt-section="add-record"]');
      return;
    }
    if (event.name === 'delete-habit-record') {
      const id = event.source && event.source.dataset ? String(event.source.dataset.id || '') : '';
      state.data.records = (state.data.records || []).filter((record) => record.id !== id);
      state.data.count = state.data.records.length;
      state.data.updatedAt = new Date().toISOString();
      await saveHabit(ctx, state.data);
      paint(ctx, state);
      openDetail(ctx, state, '已删除该记录', true, '[data-vt-section="habit-records"]');
      return;
    }
    if (event.name === 'undo-habit') {
      state.data.records = (state.data.records || []).slice(0, -1);
      state.data.count = state.data.records.length;
      state.data.updatedAt = new Date().toISOString();
      await saveHabit(ctx, state.data);
      paint(ctx, state);
      openDetail(ctx, state, '已撤销一次记录', true, '[data-vt-section="habit-records"]');
      return;
    }
    if (event.name === 'reset-habit') {
      state.data.records = [];
      state.data.count = 0;
      state.data.updatedAt = new Date().toISOString();
      await saveHabit(ctx, state.data);
      paint(ctx, state);
      openDetail(ctx, state, '今天已重置', true, '[data-vt-section="habit-records"]');
    }
  },
});

function todayKey() {
  return new Date().toLocaleDateString('zh-CN');
}

function defaultHabit(ctx) {
  const title = ctx.settings && typeof ctx.settings.habitTitle === 'string' ? ctx.settings.habitTitle.trim() : '';
  return {day: todayKey(), title: title || '今日专注', count: 0, target: 4, minutes: 25, updatedAt: '', records: []};
}

function normalizeHabit(value, ctx) {
  const base = defaultHabit(ctx);
  const source = value && typeof value === 'object' ? value : {};
  const next = {
    day: String(source.day || base.day),
    title: String(source.title || base.title).slice(0, 24),
    count: clampNumber(source.count, 0, 99),
    target: clampNumber(source.target || base.target, 1, 12),
    minutes: clampNumber(source.minutes || base.minutes, 5, 180),
    updatedAt: String(source.updatedAt || ''),
    records: normalizeRecords(source.records),
  };
  if (!next.records.length && next.count > 0) {
    next.records = Array.from({length: Math.min(next.count, 24)}, (_, index) => ({
      id: 'legacy-' + index,
      at: next.updatedAt || new Date().toISOString(),
      note: '',
    }));
  }
  next.count = next.records.length;
  ensureToday(next);
  return next;
}

function normalizeRecords(records) {
  const list = Array.isArray(records) ? records : [];
  return list.map((record, index) => ({
    id: String(record && record.id || ('record-' + index + '-' + Date.now())),
    at: String(record && record.at || new Date().toISOString()),
    note: String(record && record.note || '').slice(0, 80),
  })).slice(0, 48);
}

async function loadHabit(ctx) {
  try {
    return normalizeHabit(await ctx.storage.get(HABIT_KEY), ctx);
  } catch (e) {
    return defaultHabit(ctx);
  }
}

async function saveHabit(ctx, data) {
  try {
    await ctx.storage.set(HABIT_KEY, data);
  } catch (e) {}
}

function ensureToday(data) {
  const day = todayKey();
  if (data.day !== day) {
    data.day = day;
    data.count = 0;
    data.records = [];
    data.updatedAt = '';
  }
}

function addHabitRecord(data, note) {
  ensureToday(data);
  data.records = normalizeRecords(data.records);
  if (data.records.length >= 48) data.records = data.records.slice(-47);
  const now = new Date().toISOString();
  data.records.push({id: 'r-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6), at: now, note: String(note || '').trim().slice(0, 80)});
  data.count = data.records.length;
  data.updatedAt = now;
}

function clampNumber(value, min, max) {
  const number = Math.round(Number(value));
  if (!Number.isFinite(number)) return min;
  return Math.max(min, Math.min(max, number));
}

function readText(data, key, fallback) {
  const value = data && data[key];
  return String(Array.isArray(value) ? value[0] : value || fallback || '').trim();
}

function paint(ctx, state) {
  const data = state.data;
  ensureToday(data);
  data.records = normalizeRecords(data.records);
  data.count = data.records.length;
  const done = Math.min(data.count, data.target);
  const percent = Math.round(done / data.target * 100);
  const placement = ctx.size && ctx.size.placement ? ctx.size.placement : {w: 2, h: 2};
  state.button.classList.toggle('is-compact', placement.w <= 1 || placement.h <= 1);
  state.button.classList.toggle('is-complete', done >= data.target);
  state.button.style.setProperty('--progress', percent + '%');
  state.button.innerHTML =
    '<span class="habit-kicker">' + escapeText(data.title) + '</span>' +
    '<strong>' + done + '<small>/' + data.target + '</small></strong>' +
    '<span class="habit-bar"><i></i></span>' +
    '<span class="habit-foot">' + (done >= data.target ? '目标完成' : '点击记录一次') + ' · ' + (done * data.minutes) + ' 分钟</span>';
}

function escapeText(value) {
  return String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
}

function buildHabitRows(data) {
  const esc = VoidTabDesigner.escapeHtml;
  const records = normalizeRecords(data.records).slice().reverse();
  if (!records.length) return '<p class="console-empty">今天还没有记录。</p>';
  return records.map((record) => {
    const time = record.at ? new Date(record.at).toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'}) : '--:--';
    return '<div class="habit-record-row"><span>' + esc(time) + '</span><b>' + esc(record.note || '完成一次') + '</b><button type="button" class="row-danger" data-vt-action="delete-habit-record" data-id="' + esc(record.id) + '">删除</button></div>';
  }).join('');
}

function openDetail(ctx, state, notice, updateOnly, scrollTarget) {
  const data = state.data;
  ensureToday(data);
  data.records = normalizeRecords(data.records);
  data.count = data.records.length;
  const done = Math.min(data.count, data.target);
  const percent = Math.round(done / data.target * 100);
  const remaining = Math.max(0, data.target - done);
  const esc = VoidTabDesigner.escapeHtml;
  const updatedText = data.updatedAt ? new Date(data.updatedAt).toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'}) : '尚未记录';
  const rows = buildHabitRows(data);
  const html =
    '<main class="modal-card habit-detail">' +
      '<header class="sample-hero"><div><span>' + esc(data.title) + '</span><h1>' + done + ' / ' + data.target + '</h1><p>' + (remaining ? '还差 ' + remaining + ' 次完成今日目标' : '今日目标已经完成') + '</p></div><i class="hero-badge">' + percent + '%</i></header>' +
      '<section class="habit-meter"><b style="width:' + percent + '%"></b></section>' +
      '<section class="habit-stats">' +
        '<article><span>完成率</span><b>' + percent + '%</b></article>' +
        '<article><span>累计时长</span><b>' + (done * data.minutes) + ' 分钟</b></article>' +
        '<article><span>最后记录</span><b>' + esc(updatedText) + '</b></article>' +
      '</section>' +
      '<form class="habit-settings" data-vt-action="save-habit-settings">' +
        '<section data-vt-section="habit-settings">' + (notice ? '<p class="section-notice">' + esc(notice) + '</p>' : '') + '<section class="inline-fields"><label class="inline-field"><span>习惯名称</span><input name="habitTitle" value="' + esc(data.title) + '"></label><label class="inline-field"><span>今日目标</span><input name="target" type="number" min="1" max="12" value="' + data.target + '"></label></section></section>' +
        '<label class="inline-field"><span>单次时长（分钟）</span><input name="minutes" type="number" min="5" max="180" value="' + data.minutes + '"></label>' +
        '<section class="sample-section" data-vt-section="habit-records"><div class="section-head"><h2>今日记录</h2><span>可删除任意一条</span></div><div class="habit-records">' + rows + '</div></section>' +
        '<section class="sample-section add-record" data-vt-section="add-record"><div class="section-head"><h2>新增记录</h2><span>保存到本实例</span></div><label class="inline-field"><span>备注</span><input name="newRecordNote" placeholder="例如：阅读 25 分钟 / 完成训练"></label><button type="button" class="primary-action" data-vt-action="add-habit-record">新增记录</button></section>' +
        '<div class="modal-actions"><button type="submit" class="primary-action" data-vt-action="save-habit-settings">保存设置</button><button type="button" class="secondary-action" data-vt-action="undo-habit">撤销最后一次</button><button type="button" class="secondary-action" data-vt-action="reset-habit">重置今天</button></div>' +
      '</form>' +
      '<p class="habit-note">封面点击会立刻记录并保存到本组件实例；目标和时长可在这里调整。</p>' +
    '</main>';
  const payload = {title: '习惯进度', html: html, scrollTarget: scrollTarget || ''};
  return updateOnly ? VoidTabDesigner.updateModal(ctx, payload) : VoidTabDesigner.openModal(ctx, payload);
}`,Ye=`${dt}
.habit-card{
  padding:16px;border:0;
  display:grid;grid-template-rows:auto 1fr auto auto;gap:9px;
}
.habit-kicker,.habit-foot{font-size:11px;font-weight:900;color:var(--sample-muted)}
.habit-card strong{align-self:end;font-size:clamp(32px,18cqw,68px);line-height:.92;font-weight:950;letter-spacing:0;font-variant-numeric:tabular-nums}
.habit-card strong small{font-size:.42em;color:var(--sample-muted)}
.habit-bar{height:10px;border-radius:999px;background:color-mix(in srgb,var(--sample-text) 11%,transparent);overflow:hidden}
.habit-bar i{display:block;width:var(--progress,0%);height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--sample-accent),color-mix(in srgb,var(--sample-accent) 40%,#fff));transition:width .18s ease}
.habit-foot{color:var(--sample-accent)}
.habit-card.is-complete{--sample-accent:#22c55e}
.habit-card.is-compact{place-items:center;text-align:center;padding:12px}.habit-card.is-compact .habit-kicker,.habit-card.is-compact .habit-foot{display:none}.habit-card.is-compact .habit-bar{width:100%}
`,Ze=`<main class="modal-card habit-detail">
  <header class="sample-hero">
    <div>
      <span>HABIT TRACKER</span>
      <h1>3 / 4</h1>
      <p>还差 1 次完成今日目标。</p>
    </div>
    <i class="hero-badge">75%</i>
  </header>
  <section class="habit-meter"><b style="width:75%"></b></section>
  <section class="habit-stats">
    <article><span>完成率</span><b>75%</b></article>
    <article><span>累计时长</span><b>75 分钟</b></article>
    <article><span>最后记录</span><b>09:41</b></article>
  </section>
  <section class="inline-fields">
    <label class="inline-field"><span>今日目标</span><input type="number" min="1" value="4"></label>
    <label class="inline-field"><span>单次时长</span><input type="number" min="5" value="25"></label>
  </section>
  <section class="sample-section">
    <div class="section-head"><h2>今日记录</h2><span>可删除任意一条</span></div>
    <div class="habit-records">
      <div class="habit-record-row"><span>09:41</span><b>专注完成</b><button type="button" class="row-danger">删除</button></div>
      <div class="habit-record-row"><span>08:55</span><b>晨间阅读</b><button type="button" class="row-danger">删除</button></div>
    </div>
  </section>
  <section class="sample-section add-record"><div class="section-head"><h2>新增记录</h2><span>保存到本实例</span></div><label class="inline-field"><span>备注</span><input placeholder="例如：阅读 25 分钟"></label><button type="button" class="primary-action">新增记录</button></section>
  <p class="habit-note">点击封面会记录一次进度，并用实例存储保存当天状态。</p>
</main>`,Qe=`${pt}
.section-notice{margin:0 0 10px!important;padding:8px 10px;border-radius:12px;border:1px solid color-mix(in srgb,var(--sample-accent) 30%,transparent);background:color-mix(in srgb,var(--sample-accent) 9%,transparent);color:var(--sample-accent)!important;font-size:12px;font-weight:850}
.habit-settings{margin-top:14px}
.habit-records{display:grid;gap:8px}
.habit-record-row{display:grid;grid-template-columns:64px minmax(0,1fr) auto;gap:8px;align-items:center;padding:9px;border-radius:14px;border:1px solid var(--sample-line);background:color-mix(in srgb,var(--sample-surface) 70%,transparent)}
.habit-record-row span{font-size:12px;font-weight:950;color:var(--sample-accent);font-variant-numeric:tabular-nums}
.habit-record-row b{min-width:0;font-size:13px;line-height:1.25;overflow-wrap:anywhere}
.add-record{display:grid;gap:10px}
.modal-actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:14px}
.primary-action,.secondary-action{height:36px;padding:0 14px;border-radius:12px;border:1px solid var(--sample-line);font-size:13px;font-weight:950;color:var(--sample-text);background:color-mix(in srgb,var(--sample-surface) 80%,transparent)}
.primary-action{border-color:color-mix(in srgb,var(--sample-accent) 44%,transparent);background:var(--sample-accent);color:#fff}
.row-danger{height:32px;padding:0 10px;border-radius:10px;border:1px solid color-mix(in srgb,#ef4444 36%,transparent);font-size:12px;font-weight:950;background:color-mix(in srgb,var(--sample-surface) 78%,transparent);color:#ef4444}
@media(max-width:560px){.habit-record-row{grid-template-columns:1fr}.habit-record-row button{width:max-content}}
`,Xe=JSON.stringify({type:"object",additionalProperties:!0,properties:{habitTitle:{type:"string",title:"习惯名称",default:"今日专注",maxLength:24}}},null,2),ta=`// 网络名片：展示出口 IP、位置和运营商，支持缓存与手动刷新。
const NETWORK_CACHE_KEY = 'network-card-cache-v2';

VoidWidget.define({
  async mount(ctx) {
    const card = document.createElement('button');
    card.className = 'net-card is-loading';
    card.type = 'button';
    card.innerHTML =
      '<div class="net-pulse"></div>' +
      '<div class="net-copy"><span>网络</span><strong>加载中</strong><small>等待请求返回</small></div>';
    ctx.root.appendChild(card);

    const state = {card, loading: false, snapshot: loadingSnapshot(), pins: [], label: '', note: ''};
    this._state = state;
    card.addEventListener('click', () => openDetail(ctx, state));

    try {
      const cached = await ctx.storage.get(NETWORK_CACHE_KEY);
      const normalized = normalizeCache(cached);
      state.snapshot = normalized.snapshot;
      state.pins = normalized.pins;
      state.label = normalized.label;
      state.note = normalized.note;
    } catch (e) {}
    paint(ctx, state);
    await refreshNetwork(ctx, state, false);
  },
  async modalEvent(ctx, event) {
    const state = this._state;
    if (!state) return;
    if (event.name === 'refresh-network') {
      await refreshNetwork(ctx, state, true);
      return;
    }
    if (event.name === 'save-network-note') {
      state.label = readText(event.data, 'label', state.label).slice(0, 36);
      state.note = readText(event.data, 'note', state.note).slice(0, 140);
      await saveNetworkState(ctx, state);
      openDetail(ctx, state, '备注已保存', true, '[data-vt-section="network-note"]');
      return;
    }
    if (event.name === 'pin-network') {
      state.pins = [createPin(state), ...state.pins].slice(0, 8);
      await saveNetworkState(ctx, state);
      openDetail(ctx, state, '已收藏当前网络快照', true, '[data-vt-section="network-pins"]');
      return;
    }
    if (event.name === 'delete-network-pin') {
      const id = event.source && event.source.dataset ? String(event.source.dataset.id || '') : '';
      state.pins = state.pins.filter((pin) => pin.id !== id);
      await saveNetworkState(ctx, state);
      openDetail(ctx, state, '已删除该快照', true, '[data-vt-section="network-pins"]');
    }
  },
});

function loadingSnapshot() {
  return {
    ok: false,
    ip: '加载中',
    place: '网络',
    isp: '正在请求网络信息',
    timezone: '',
    country: '',
    countryCode: '',
    continent: '',
    organization: '',
    asn: '',
    coordinate: '',
    updatedAt: '',
    error: '',
  };
}

function normalizeSnapshot(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  return {
    ok: source.ok === true,
    ip: String(source.ip || '未知 IP'),
    place: String(source.place || '未知位置'),
    isp: String(source.isp || '未知运营商'),
    timezone: String(source.timezone || ''),
    country: String(source.country || ''),
    countryCode: String(source.countryCode || ''),
    continent: String(source.continent || ''),
    organization: String(source.organization || ''),
    asn: String(source.asn || ''),
    coordinate: String(source.coordinate || ''),
    updatedAt: String(source.updatedAt || ''),
    error: String(source.error || ''),
  };
}

function normalizePin(raw) {
  const source = raw && typeof raw === 'object' ? raw : {};
  return {
    id: String(source.id || ('pin-' + Date.now())),
    ip: String(source.ip || '未知 IP'),
    place: String(source.place || '未知位置'),
    isp: String(source.isp || '未知运营商'),
    at: String(source.at || new Date().toISOString()),
  };
}

function normalizeCache(raw) {
  if (raw && raw.ip) {
    return {snapshot: normalizeSnapshot(raw), pins: [], label: '', note: ''};
  }
  const source = raw && typeof raw === 'object' ? raw : {};
  return {
    snapshot: source.snapshot ? normalizeSnapshot(source.snapshot) : loadingSnapshot(),
    pins: Array.isArray(source.pins) ? source.pins.map(normalizePin).slice(0, 8) : [],
    label: String(source.label || '').slice(0, 36),
    note: String(source.note || '').slice(0, 140),
  };
}

function readText(data, key, fallback) {
  const value = data && data[key];
  return String(Array.isArray(value) ? value[0] : value || fallback || '').trim();
}

function createPin(state) {
  return normalizePin({
    id: 'pin-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
    ip: state.snapshot.ip,
    place: state.snapshot.place,
    isp: state.snapshot.isp,
    at: new Date().toISOString(),
  });
}

async function saveNetworkState(ctx, state) {
  try {
    await ctx.storage.set(NETWORK_CACHE_KEY, {
      snapshot: state.snapshot,
      pins: state.pins.slice(0, 8),
      label: state.label,
      note: state.note,
    });
  } catch (e) {}
}

function paint(ctx, state) {
  const snapshot = state.snapshot;
  const placement = ctx.size && ctx.size.placement ? ctx.size.placement : {w: 2, h: 2};
  state.card.className = 'net-card ' + (state.loading ? 'is-loading' : snapshot.ok ? 'is-ok' : 'is-bad') + (placement.w <= 1 || placement.h <= 1 ? ' is-compact' : '');
  state.card.querySelector('strong').textContent = state.loading && !snapshot.ok ? '刷新中' : snapshot.ip;
  state.card.querySelector('span').textContent = snapshot.place;
  state.card.querySelector('small').textContent = state.loading ? '正在更新网络信息' : snapshot.isp;
}

async function refreshNetwork(ctx, state, showModal) {
  state.loading = true;
  paint(ctx, state);
  try {
    const res = await ctx.network.fetch('https://api.ip.sb/geoip');
    const data = JSON.parse(res.body || '{}');
    state.snapshot = normalizeSnapshot({
      ok: true,
      ip: data.ip || '未知 IP',
      place: [data.city, data.country].filter(Boolean).join(' / ') || '当前位置',
      isp: data.isp || data.organization || data.asn_organization || 'api.ip.sb',
      timezone: data.timezone || '',
      country: data.country || '',
      countryCode: data.country_code || '',
      continent: data.continent_code || '',
      organization: data.organization || data.asn_organization || '',
      asn: data.asn_organization || '',
      coordinate: [data.latitude, data.longitude].filter((item) => item !== undefined && item !== null).join(', '),
      updatedAt: new Date().toISOString(),
      error: '',
    });
    await saveNetworkState(ctx, state);
  } catch (e) {
    state.snapshot = normalizeSnapshot({
      ...state.snapshot,
      ok: false,
      ip: state.snapshot.ip === '加载中' ? '请求失败' : state.snapshot.ip,
      place: state.snapshot.place || '网络',
      isp: state.snapshot.isp || '网络请求失败',
      error: (e && e.message) || String(e),
      updatedAt: state.snapshot.updatedAt || new Date().toISOString(),
    });
  } finally {
    state.loading = false;
    paint(ctx, state);
    if (showModal) openDetail(ctx, state, state.snapshot.ok ? '网络信息已刷新' : '刷新失败，保留当前缓存', true, '[data-vt-section="network-summary"]');
  }
}

function buildNetworkPins(state) {
  const esc = VoidTabDesigner.escapeHtml;
  const pins = Array.isArray(state.pins) ? state.pins.slice(0, 8) : [];
  if (!pins.length) return '<p class="console-empty">还没有收藏网络快照。</p>';
  return pins.map((pin) => {
    const at = pin.at ? new Date(pin.at).toLocaleString('zh-CN', {hour12: false}) : '';
    return '<div class="network-pin-row"><div><b>' + esc(pin.ip) + '</b><span>' + esc(pin.place) + ' · ' + esc(pin.isp) + '</span><small>' + esc(at) + '</small></div><button type="button" class="row-danger" data-vt-action="delete-network-pin" data-id="' + esc(pin.id) + '">删除</button></div>';
  }).join('');
}

function openDetail(ctx, state, notice, updateOnly, scrollTarget) {
  const snapshot = state.snapshot;
  const esc = VoidTabDesigner.escapeHtml;
  const status = snapshot.ok ? '已连接' : (snapshot.error || '需要授权或网络不可用');
  const updated = snapshot.updatedAt ? new Date(snapshot.updatedAt).toLocaleString('zh-CN', {hour12: false}) : '尚未刷新';
  const fields = [
    ['IP 地址', snapshot.ip],
    ['位置', snapshot.place],
    ['国家 / 地区', [snapshot.country, snapshot.countryCode].filter(Boolean).join(' / ') || '未知'],
    ['运营商', snapshot.isp],
    ['组织', snapshot.organization || snapshot.asn || '未知'],
    ['时区', snapshot.timezone || '未知'],
    ['坐标', snapshot.coordinate || '未知'],
    ['更新时间', updated]
  ].map((item) => '<div class="field-row"><span>' + esc(item[0]) + '</span><b>' + esc(item[1]) + '</b></div>').join('');
  const pins = buildNetworkPins(state);
  const html =
    '<main class="modal-card net-detail">' +
      '<header class="sample-hero"><div><span>网络名片</span><h1>' + esc(snapshot.ip) + '</h1><p>' + esc(status) + '</p></div><i class="hero-badge">' + (snapshot.ok ? 'ONLINE' : 'CACHE') + '</i></header>' +
      '<section class="net-grid">' +
        '<article><span>位置</span><b>' + esc(snapshot.place) + '</b></article>' +
        '<article><span>运营商</span><b>' + esc(snapshot.isp) + '</b></article>' +
        '<article><span>时区</span><b>' + esc(snapshot.timezone || '未知') + '</b></article>' +
      '</section>' +
      '<section class="sample-section" data-vt-section="network-summary"><div class="section-head"><h2>连接字段</h2><span>结构化展示</span></div>' + (notice ? '<p class="section-notice">' + esc(notice) + '</p>' : '') + '<div class="field-list">' + fields + '</div><div class="tag-row"><span>' + esc(snapshot.countryCode || 'N/A') + '</span><span>' + esc(snapshot.continent || 'N/A') + '</span><span>' + esc(snapshot.ok ? '已刷新' : '缓存/失败') + '</span></div></section>' +
      '<form class="network-note-form" data-vt-action="save-network-note"><section class="sample-section" data-vt-section="network-note"><div class="section-head"><h2>备注</h2><span>保存到本实例</span></div><section class="inline-fields"><label class="inline-field"><span>标签</span><input name="label" value="' + esc(state.label) + '" placeholder="家里 / 公司 / 热点"></label><label class="inline-field"><span>说明</span><input name="note" value="' + esc(state.note) + '" placeholder="补充说明"></label></section></section><div class="modal-actions"><button type="submit" class="primary-action" data-vt-action="save-network-note">保存备注</button><button type="button" class="secondary-action" data-vt-action="pin-network">收藏当前快照</button><button type="button" class="secondary-action" data-vt-action="refresh-network">刷新网络信息</button></div></form>' +
      '<section class="sample-section" data-vt-section="network-pins"><div class="section-head"><h2>已收藏快照</h2><span>可删除</span></div><div class="network-pins">' + pins + '</div></section>' +
    '</main>';
  const payload = {title: '网络名片', html: html, scrollTarget: scrollTarget || ''};
  return updateOnly ? VoidTabDesigner.updateModal(ctx, payload) : VoidTabDesigner.openModal(ctx, payload);
}`,ea=`${dt}
.net-card{
  padding:14px 16px;border:0;
  display:grid;grid-template-columns:auto 1fr;align-items:center;gap:14px;text-align:left;
}
.net-pulse{width:44px;height:44px;border-radius:16px;background:var(--sample-accent);box-shadow:0 0 0 8px color-mix(in srgb,var(--sample-accent) 16%,transparent),0 12px 24px color-mix(in srgb,var(--sample-accent) 20%,transparent)}
.net-copy{min-width:0;display:grid;gap:3px}
.net-copy span{font-size:11px;font-weight:900;color:var(--sample-accent);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.net-copy strong{font-size:clamp(16px,7cqw,26px);line-height:1.05;font-weight:950;letter-spacing:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.net-copy small{font-size:11px;line-height:1.25;color:var(--sample-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.net-card.is-bad{--sample-accent:#ef4444}
.net-card.is-loading{--sample-accent:#0ea5e9}
.net-card.is-loading .net-pulse{animation:netPulse 1.3s ease-in-out infinite}
.net-card.is-compact{place-items:center;grid-template-columns:1fr;text-align:center;padding:12px}.net-card.is-compact .net-pulse{width:38px;height:38px}.net-card.is-compact small{display:none}
@keyframes netPulse{0%,100%{transform:scale(1);opacity:.78}50%{transform:scale(1.08);opacity:1}}
}`,aa=`<main class="modal-card net-detail">
  <header class="sample-hero">
    <div>
      <span>NETWORK CARD</span>
      <h1>203.0.113.42</h1>
      <p>已连接 · 请求返回后会展示真实 IP 和位置。</p>
    </div>
    <i class="hero-badge">ONLINE</i>
  </header>
  <section class="net-grid">
    <article><span>位置</span><b>Shanghai / CN</b></article>
    <article><span>运营商</span><b>Example ISP</b></article>
    <article><span>时区</span><b>Asia/Shanghai</b></article>
  </section>
  <section class="sample-section">
    <div class="section-head"><h2>连接字段</h2><span>结构化展示</span></div>
    <div class="field-list">
      <div class="field-row"><span>IP 地址</span><b>203.0.113.42</b></div>
      <div class="field-row"><span>位置</span><b>Shanghai / CN</b></div>
      <div class="field-row"><span>运营商</span><b>Example ISP</b></div>
      <div class="field-row"><span>组织</span><b>Example Network</b></div>
    </div>
    <div class="tag-row"><span>CN</span><span>AS</span><span>授权成功</span></div>
  </section>
  <section class="sample-section"><div class="section-head"><h2>备注</h2><span>保存到本实例</span></div><section class="inline-fields"><label class="inline-field"><span>标签</span><input value="公司网络"></label><label class="inline-field"><span>说明</span><input value="办公 Wi-Fi"></label></section></section>
  <div class="modal-actions"><button type="button" class="primary-action">保存备注</button><button type="button" class="secondary-action">收藏当前快照</button><button type="button" class="secondary-action">刷新网络信息</button></div>
  <section class="sample-section"><div class="section-head"><h2>已收藏快照</h2><span>可删除</span></div><div class="network-pins"><div class="network-pin-row"><div><b>203.0.113.42</b><span>Shanghai / CN · Example ISP</span><small>2026/6/27 09:41:00</small></div><button type="button" class="row-danger">删除</button></div></div></section>
</main>`,na=`${pt}
.section-notice{margin:0 0 10px!important;padding:8px 10px;border-radius:12px;border:1px solid color-mix(in srgb,var(--sample-accent) 30%,transparent);background:color-mix(in srgb,var(--sample-accent) 9%,transparent);color:var(--sample-accent)!important;font-size:12px;font-weight:850}
.modal-actions{display:flex;flex-wrap:wrap;gap:9px;margin-top:14px}
.primary-action,.secondary-action{height:36px;padding:0 14px;border-radius:12px;border:1px solid var(--sample-line);font-size:13px;font-weight:950;color:var(--sample-text);background:color-mix(in srgb,var(--sample-surface) 80%,transparent)}
.primary-action{border-color:color-mix(in srgb,var(--sample-accent) 44%,transparent);background:var(--sample-accent);color:#fff}
.network-note-form{margin-top:14px}
.network-pins{display:grid;gap:8px}
.network-pin-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;padding:10px;border-radius:14px;border:1px solid var(--sample-line);background:color-mix(in srgb,var(--sample-surface) 70%,transparent)}
.network-pin-row div{min-width:0;display:grid;gap:2px}
.network-pin-row b{font-size:14px;line-height:1.2;overflow-wrap:anywhere}
.network-pin-row span,.network-pin-row small{font-size:11px;color:var(--sample-muted);overflow-wrap:anywhere}
.row-danger{height:32px;padding:0 10px;border-radius:10px;border:1px solid color-mix(in srgb,#ef4444 36%,transparent);font-size:12px;font-weight:950;background:color-mix(in srgb,var(--sample-surface) 78%,transparent);color:#ef4444}
@media(max-width:560px){.network-pin-row{grid-template-columns:1fr}.network-pin-row button{width:max-content}}
`,sa=`// 备忘录：封面显示备忘条数与当前时间；点击打开主从布局弹窗（左列列表 / 右侧详情），支持新增、编辑、删除。
const MEMO_KEY = 'memo-notes-v1';

VoidWidget.define({
  async mount(ctx) {
    const root = document.createElement('button');
    root.className = 'memo-cover';
    root.type = 'button';
    root.innerHTML =
      '<div class="mc-head"><span class="mc-kicker">备忘录</span><b class="mc-count">0</b></div>' +
      '<div class="mc-clock"><strong class="mc-time">--:--</strong><small class="mc-date"></small></div>' +
      '<div class="mc-foot"><span class="mc-latest">还没有备忘</span></div>';
    ctx.root.appendChild(root);

    const state = {root, notes: await loadNotes(ctx), activeId: ''};
    if (state.notes.length) state.activeId = state.notes[0].id;
    this._state = state;
    this._render = () => renderCover(ctx, state);
    root.addEventListener('click', () => openDetail(ctx, state));
    this._render();
    this._timer = setInterval(this._render, 1000);
  },
  pause() { if (this._timer) clearInterval(this._timer); this._timer = null; },
  resume() {
    if (this._timer || !this._render) return;
    this._render();
    this._timer = setInterval(this._render, 1000);
  },
  unmount() { if (this._timer) clearInterval(this._timer); this._timer = null; },
  async modalEvent(ctx, event) {
    const state = this._state;
    if (!state) return;
    if (event.name === 'select-note') {
      const id = event.source && event.source.dataset ? event.source.dataset.id : '';
      if (id) state.activeId = id;
      openDetail(ctx, state, true);
      return;
    }
    if (event.name === 'add-note') {
      const note = {
        id: 'n-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6),
        title: '新备忘',
        content: '',
        tags: [],
        updatedAt: new Date().toISOString(),
      };
      state.notes.unshift(note);
      state.activeId = note.id;
      await saveNotes(ctx, state.notes);
      renderCover(ctx, state);
      openDetail(ctx, state, true, '[data-vt-field="title"]');
      return;
    }
    if (event.name === 'save-note') {
      const note = findNote(state, state.activeId);
      if (note) {
        note.title = readValue(event.data, 'title').trim().slice(0, 60) || '未命名';
        note.content = readValue(event.data, 'content').slice(0, 4000);
        note.tags = parseTags(readValue(event.data, 'tags'));
        note.updatedAt = new Date().toISOString();
        state.notes = sortNotes(state.notes);
        state.activeId = note.id;
      }
      await saveNotes(ctx, state.notes);
      renderCover(ctx, state);
      openDetail(ctx, state, true);
      return;
    }
    if (event.name === 'delete-note') {
      const id = event.source && event.source.dataset ? event.source.dataset.id : '';
      state.notes = state.notes.filter((n) => n.id !== id);
      if (state.activeId === id) state.activeId = state.notes.length ? state.notes[0].id : '';
      await saveNotes(ctx, state.notes);
      renderCover(ctx, state);
      openDetail(ctx, state, true);
    }
  },
});

function normalizeNote(raw) {
  const s = raw && typeof raw === 'object' ? raw : {};
  return {
    id: String(s.id || ('n-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6))),
    title: String(s.title || '未命名').slice(0, 60),
    content: String(s.content || '').slice(0, 4000),
    tags: Array.isArray(s.tags) ? s.tags.map((t) => String(t).trim()).filter(Boolean).slice(0, 6) : [],
    updatedAt: String(s.updatedAt || new Date().toISOString()),
  };
}

function sortNotes(notes) {
  return notes.slice().sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)));
}

function normalizeNotes(raw) {
  const list = Array.isArray(raw) ? raw : [];
  return sortNotes(list.map(normalizeNote)).slice(0, 100);
}

async function loadNotes(ctx) {
  try { return normalizeNotes(await ctx.storage.get(MEMO_KEY)); } catch (e) { return []; }
}

async function saveNotes(ctx, notes) {
  try { await ctx.storage.set(MEMO_KEY, notes); } catch (e) {}
}

function findNote(state, id) {
  return state.notes.find((n) => n.id === id) || null;
}

function readValue(data, key) {
  const v = data && data[key];
  return String(Array.isArray(v) ? v[0] : (v || ''));
}

function parseTags(text) {
  return String(text || '').split(/[,，\\s]+/).map((t) => t.trim()).filter(Boolean).slice(0, 6);
}

function fmtClock(date) {
  return date.toLocaleTimeString('zh-CN', {hour: '2-digit', minute: '2-digit'});
}
function fmtDate(date) {
  return date.toLocaleDateString('zh-CN', {month: 'long', day: 'numeric', weekday: 'short'});
}
function fmtUpdated(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleString('zh-CN', {month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit'});
}

function renderCover(ctx, state) {
  if (!state.root) return;
  const now = new Date();
  const p = ctx.size && ctx.size.placement ? ctx.size.placement : {w: 2, h: 2};
  state.root.classList.toggle('is-compact', p.w <= 1 || p.h <= 1);
  state.root.querySelector('.mc-count').textContent = String(state.notes.length);
  state.root.querySelector('.mc-time').textContent = fmtClock(now);
  state.root.querySelector('.mc-date').textContent = fmtDate(now);
  const latest = state.notes[0];
  state.root.querySelector('.mc-latest').textContent = latest ? ('最近：' + latest.title) : '还没有备忘，点击新增';
}

function openDetail(ctx, state, updateOnly, scrollTarget) {
  const esc = VoidTabDesigner.escapeHtml;
  const count = state.notes.length;
  const active = findNote(state, state.activeId);

  const list = count
    ? state.notes.map((n) => {
        const meta = [fmtUpdated(n.updatedAt)].concat(n.tags.slice(0, 2)).filter(Boolean).join(' · ');
        return '<button type="button" class="list-item memo-item' + (n.id === state.activeId ? ' is-active' : '') + '" data-vt-action="select-note" data-id="' + esc(n.id) + '">' +
            '<b class="memo-item-title">' + esc(n.title || '未命名') + '</b>' +
            '<span class="memo-item-meta">' + esc(meta || '尚未编辑') + '</span>' +
          '</button>';
      }).join('')
    : '<div class="empty">还没有备忘</div>';

  const pane = active
    ? '<form class="pane memo-form" data-vt-action="save-note">' +
        '<input class="input memo-title-input" name="title" data-vt-field="title" value="' + esc(active.title) + '" placeholder="标题" maxlength="60" autocomplete="off">' +
        '<div class="memo-updated">更新于 ' + esc(fmtUpdated(active.updatedAt) || '—') + '</div>' +
        '<textarea class="textarea" name="content" placeholder="在这里输入备忘内容...">' + esc(active.content) + '</textarea>' +
        '<input class="input" name="tags" value="' + esc(active.tags.join(', ')) + '" placeholder="标签，用逗号分隔" autocomplete="off">' +
        (active.tags.length ? '<div class="memo-tags">' + active.tags.map((t) => '<span class="chip">' + esc(t) + '</span>').join('') + '</div>' : '') +
        '<div class="memo-actions">' +
          '<button type="submit" class="btn primary" data-vt-action="save-note">保存</button>' +
          '<button type="button" class="btn danger" data-vt-action="delete-note" data-id="' + esc(active.id) + '">删除</button>' +
        '</div>' +
      '</form>'
    : '<div class="pane"><div class="empty">从左侧选择一条备忘，或点击右上角「新增」</div></div>';

  const html =
    '<main class="memo-detail">' +
      '<header class="memo-bar">' +
        '<div class="memo-bar-title"><b>备忘录</b><span>' + count + ' 条</span></div>' +
        '<button type="button" class="btn primary" data-vt-action="add-note">＋ 新增</button>' +
      '</header>' +
      '<div class="detail-layout">' +
        '<div class="list memo-list">' + list + '</div>' +
        pane +
      '</div>' +
    '</main>';

  const payload = {title: '备忘录', html: html, scrollTarget: scrollTarget || ''};
  return updateOnly ? VoidTabDesigner.updateModal(ctx, payload) : VoidTabDesigner.openModal(ctx, payload);
}`,ia=`.memo-cover{
  position:relative;overflow:hidden;width:100%;height:100%;box-sizing:border-box;
  display:grid;grid-template-rows:auto 1fr auto;gap:10px;padding:16px;text-align:left;cursor:pointer;
  border:1px solid color-mix(in srgb,var(--vt-text,#e8eaed) 12%,transparent);border-radius:inherit;color:var(--vt-text,#e8eaed);
  background:
    linear-gradient(135deg,color-mix(in srgb,var(--vt-accent,#3b82f6) 14%,transparent),transparent 56%),
    color-mix(in srgb,var(--vt-surface,rgba(255,255,255,.08)) 92%,transparent);
  box-shadow:inset 0 1px 0 color-mix(in srgb,#fff 16%,transparent);
  transition:transform .16s ease,border-color .16s ease;
}
.memo-cover:hover{border-color:color-mix(in srgb,var(--vt-accent,#3b82f6) 42%,transparent)}
.memo-cover:active{transform:scale(.99)}
.mc-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.mc-kicker{font-size:11px;font-weight:900;color:var(--vt-accent,#3b82f6)}
.mc-count{min-width:26px;height:24px;padding:0 8px;display:inline-flex;align-items:center;justify-content:center;border-radius:999px;font-size:13px;font-weight:950;font-variant-numeric:tabular-nums;background:color-mix(in srgb,var(--vt-accent,#3b82f6) 16%,transparent);color:var(--vt-accent,#3b82f6)}
.mc-clock{display:flex;align-items:baseline;gap:8px;min-width:0}
.mc-time{font-size:clamp(30px,22vw,54px);line-height:1;font-weight:950;font-variant-numeric:tabular-nums}
.mc-date{font-size:12px;font-weight:800;color:var(--vt-muted,rgba(232,234,237,.66));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mc-foot{min-width:0}
.mc-latest{display:block;font-size:12px;line-height:1.35;color:var(--vt-muted,rgba(232,234,237,.66));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.memo-cover.is-compact{grid-template-rows:auto auto;gap:6px;padding:12px;place-content:center;text-align:center}
.memo-cover.is-compact .mc-foot,.memo-cover.is-compact .mc-date{display:none}
.memo-cover.is-compact .mc-clock{justify-content:center}
`,oa=`<main class="memo-detail">
  <header class="memo-bar">
    <div class="memo-bar-title"><b>备忘录</b><span>2 条</span></div>
    <button type="button" class="btn primary" data-vt-action="add-note">＋ 新增</button>
  </header>
  <div class="detail-layout">
    <div class="list memo-list">
      <button type="button" class="list-item memo-item is-active" data-vt-action="select-note" data-id="demo1"><b class="memo-item-title">购物清单</b><span class="memo-item-meta">06-28 21:40 · 生活</span></button>
      <button type="button" class="list-item memo-item" data-vt-action="select-note" data-id="demo2"><b class="memo-item-title">会议要点</b><span class="memo-item-meta">06-28 18:02 · 工作</span></button>
    </div>
    <form class="pane memo-form" data-vt-action="save-note">
      <input class="input memo-title-input" name="title" data-vt-field="title" value="购物清单" placeholder="标题" maxlength="60">
      <div class="memo-updated">更新于 06-28 21:40</div>
      <textarea class="textarea" name="content" placeholder="在这里输入备忘内容...">牛奶、鸡蛋、面包；周末去超市补货。</textarea>
      <input class="input" name="tags" value="生活, 待办" placeholder="标签，用逗号分隔">
      <div class="memo-tags"><span class="chip">生活</span><span class="chip">待办</span></div>
      <div class="memo-actions">
        <button type="submit" class="btn primary" data-vt-action="save-note">保存</button>
        <button type="button" class="btn danger" data-vt-action="delete-note" data-id="demo1">删除</button>
      </div>
    </form>
  </div>
</main>`,ra=`.memo-detail{display:flex;flex-direction:column;gap:14px;height:100%;min-height:0;padding:18px;color:var(--vt-text,#e8eaed)}
.memo-bar{display:flex;align-items:center;justify-content:space-between;gap:12px}
.memo-bar-title{display:flex;align-items:baseline;gap:8px}
.memo-bar-title b{font-size:16px;font-weight:950}
.memo-bar-title span{font-size:12px;color:var(--vt-muted,rgba(232,234,237,.66))}
.detail-layout{flex:1;min-height:0;display:grid;grid-template-columns:240px minmax(0,1fr);gap:14px}
.list{display:grid;gap:6px;align-content:start;overflow:auto;padding-right:2px}
.list-item{display:grid;gap:3px;padding:10px 12px;border-radius:12px;border:1px solid color-mix(in srgb,var(--vt-text,#e8eaed) 12%,transparent);background:color-mix(in srgb,var(--vt-surface,rgba(255,255,255,.08)) 78%,transparent);cursor:pointer;text-align:left}
.list-item:hover{border-color:color-mix(in srgb,var(--vt-accent,#3b82f6) 40%,transparent)}
.list-item.is-active{border-color:var(--vt-accent,#3b82f6);background:color-mix(in srgb,var(--vt-accent,#3b82f6) 12%,transparent)}
.memo-item-title{font-size:13px;font-weight:800;line-height:1.25;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.memo-item-meta{font-size:11px;color:var(--vt-muted,rgba(232,234,237,.66));white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pane{display:flex;flex-direction:column;gap:10px;min-width:0}
.input,.textarea{width:100%;box-sizing:border-box;border:1px solid color-mix(in srgb,var(--vt-text,#e8eaed) 12%,transparent);border-radius:10px;background:color-mix(in srgb,var(--vt-surface,rgba(255,255,255,.08)) 82%,transparent);color:var(--vt-text,#e8eaed);font:inherit;outline:none}
.input{height:36px;padding:0 12px;font-weight:700}
.memo-title-input{font-size:15px;font-weight:900}
.textarea{flex:1;min-height:160px;padding:12px;resize:none;line-height:1.6;font-size:13px}
.input:focus,.textarea:focus{border-color:var(--vt-accent,#3b82f6)}
.memo-updated{font-size:11px;color:var(--vt-muted,rgba(232,234,237,.66))}
.memo-tags{display:flex;flex-wrap:wrap;gap:6px}
.chip{display:inline-flex;align-items:center;padding:3px 9px;border-radius:999px;border:1px solid color-mix(in srgb,var(--vt-text,#e8eaed) 12%,transparent);background:color-mix(in srgb,var(--vt-surface,rgba(255,255,255,.08)) 74%,transparent);font-size:11px;color:var(--vt-muted,rgba(232,234,237,.66))}
.memo-actions{display:flex;gap:9px;margin-top:2px}
.btn{height:36px;padding:0 16px;border-radius:10px;font-size:13px;font-weight:850;cursor:pointer;border:1px solid color-mix(in srgb,var(--vt-text,#e8eaed) 12%,transparent);background:color-mix(in srgb,var(--vt-surface,rgba(255,255,255,.08)) 80%,transparent);color:var(--vt-text,#e8eaed)}
.btn.primary{border-color:transparent;background:var(--vt-accent,#3b82f6);color:#fff}
.btn.danger{border-color:color-mix(in srgb,#ef4444 40%,transparent);color:#ef4444;background:color-mix(in srgb,#ef4444 8%,transparent)}
.empty{display:grid;place-items:center;height:100%;min-height:120px;color:var(--vt-muted,rgba(232,234,237,.66));font-size:12px;text-align:center;padding:16px}
@media(max-width:640px){.detail-layout{grid-template-columns:1fr;overflow:auto}.list{max-height:160px}}
`,rt=[{id:"memo",label:"备忘录",description:"封面看条数与时间，弹窗左列列表 / 右侧详情，支持增删改与标签。",draft:()=>({id:`my.memo-${Math.random().toString(36).slice(2,6)}`,label:"备忘录",description:"记录备忘标题、内容、时间与标签，主从布局编辑。",icon:"NotePencil",category:"local",version:"0.1.0",sizes:{default:{w:2,h:2},min:{w:1,h:1},max:{w:4,h:3}},permissions:["storage"],networkHosts:[],entryCode:sa,styles:ia,modalHtml:oa,modalStyles:ra,modalWidth:"880px",modalHeight:"620px",html:"",settingsSchemaText:""})},{id:"clock",label:"时间看板",description:"时间、日期、闹钟与今日计划，适合放在桌面第一屏。",draft:()=>({id:`my.clock-${Math.random().toString(36).slice(2,6)}`,label:"时间看板",description:"查看时间日期，维护闹钟和今日计划。",icon:"Clock",category:"local",version:"0.1.0",sizes:{default:{w:2,h:2},min:{w:1,h:1},max:{w:4,h:3}},permissions:["storage","notifications"],networkHosts:[],entryCode:We,styles:qe,modalHtml:Ge,modalStyles:Ke,modalWidth:"820px",modalHeight:"680px",html:"",settingsSchemaText:Be})},{id:"counter",label:"习惯进度",description:"点击记录今日进度，并写入实例存储。",draft:()=>({id:`my.counter-${Math.random().toString(36).slice(2,6)}`,label:"习惯进度",description:"记录每日专注次数。",icon:"Cursor",category:"local",version:"0.1.0",sizes:{default:{w:2,h:2},min:{w:1,h:1},max:{w:4,h:3}},permissions:["storage"],networkHosts:[],entryCode:Fe,styles:Ye,modalHtml:Ze,modalStyles:Qe,modalWidth:"760px",modalHeight:"640px",html:"",settingsSchemaText:Xe})},{id:"fetch",label:"网络名片",description:"展示出口 IP、位置和运营商，带缓存与手动刷新。",draft:()=>({id:`my.ipinfo-${Math.random().toString(36).slice(2,6)}`,label:"网络名片",description:"展示当前出口 IP、位置和运营商。",icon:"Globe",category:"local",version:"0.1.0",sizes:{default:{w:2,h:2},min:{w:1,h:1},max:{w:6,h:3}},permissions:["storage","network"],networkHosts:["api.ip.sb"],entryCode:ta,styles:ea,modalHtml:aa,modalStyles:na,modalWidth:"820px",modalHeight:"620px",html:"",settingsSchemaText:""})}],la={class:"ai-panel"},ca={class:"ai-head"},da={class:"ai-title"},pa={class:"ai-body"},ma={class:"seg"},ua={class:"field"},ga={class:"ai-note"},va={key:0,class:"ai-section"},ba={class:"ai-model-row"},xa={class:"model-chip"},ha={key:0,class:"model-warn"},fa=["disabled"],wa={key:0,class:"ai-stream"},ya={class:"ai-stream-head"},ka={class:"ai-stream-body"},Sa={key:1,class:"ai-section"},za={class:"prompt-list"},Ta={class:"prompt-head"},Da=["onClick"],_a=["onClick"],Ca={key:0,class:"prompt-body"},Aa={class:"field mt-2"},Na=tt({__name:"DesignerAiPanel",props:{show:{type:Boolean},draft:{}},emits:["close","apply"],setup(n,{emit:r}){const a=n,c=r,d=St(),p=zt(),s=T("generate"),E=T(""),_=T(""),v=T(!1),k=T(""),A=T(""),D=S(()=>d.config.ai),W=S(()=>{var l,m;const w=D.value;return!(!w||!((l=w.baseUrl)!=null&&l.trim())||!((m=w.apiKey)!=null&&m.trim())&&!w.baseUrl.includes("localhost"))}),F=S(()=>{var w,l;return((l=(w=D.value)==null?void 0:w.model)==null?void 0:l.trim())||"未配置"}),J=S(()=>Le(E.value,a.draft)),R=w=>{A.value=A.value===w?"":w},N=async(w,l="提示词")=>{try{await navigator.clipboard.writeText(w),p.success(`已复制${l}`)}catch{p.error("复制失败，请手动选择文本")}},O=w=>{const l=Je(w);if(!l.ok||!l.draftPatch)return p.error(`解析失败：${l.error||"未知错误"}`),!1;const m=Ue(a.draft,l.draftPatch);c("apply",m);const V=ot(m);return V.ok?p.success("已填入设计器，可在预览中查看"):p.warning(`已填入，但结构需微调：${V.error||"请检查代码"}`),!0},q=async()=>{if(v.value)return;if(!E.value.trim()){p.warning("请先描述你想要的组件");return}if(!W.value){p.error("尚未配置应用内 AI，请在 AI 助手的「模型配置」里填写 Base URL / API Key，或改用「复制提示词」模式");return}const w=D.value;v.value=!0,k.value="";try{let l=w.baseUrl.trim().replace(/\/+$/,"");l.endsWith("/chat/completions")||(l=`${l}/chat/completions`);const m=await De(l,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${w.apiKey}`},body:JSON.stringify({model:w.model||"deepseek-chat",messages:[{role:"system",content:lt},{role:"user",content:ct(E.value,a.draft)}],temperature:Number.isFinite(Number(w.temperature))?Math.min(Number(w.temperature),.6):.4,stream:!0})},{timeoutMs:6e4,retries:1,retryDelayMs:800,maxRetryDelayMs:3e3,metricName:"designer.ai.generate",fallbackName:"designer.ai.unavailable"});if(!m.ok){const G=await m.text();throw new Error(`API Error ${m.status}: ${G.slice(0,200)}`)}const V=await _e(m,{onContent:G=>{k.value=G}});O(V)&&(k.value=V)}catch(l){const m=l instanceof Error?l.message:"未知错误";p.error(`生成失败：${m}`,{duration:8e3})}finally{v.value=!1}},Y=()=>{if(!_.value.trim()){p.warning("请先粘贴 AI 返回的内容");return}O(_.value)};return(w,l)=>(g(),B(Kt,{to:"body"},[n.show?(g(),h("div",{key:0,class:"ai-mask",onClick:l[6]||(l[6]=Bt(m=>c("close"),["self"]))},[t("section",la,[t("header",ca,[t("div",da,[u(b(nt),{size:"18",weight:"duotone"}),l[7]||(l[7]=x("AI 生成组件",-1))]),t("button",{type:"button",class:"icon-btn","aria-label":"关闭",onClick:l[0]||(l[0]=m=>c("close"))},[u(b(Tt),{size:"18"})])]),t("div",pa,[t("div",ma,[t("button",{type:"button",class:H(["seg-btn",{active:s.value==="generate"}]),onClick:l[1]||(l[1]=m=>s.value="generate")},"应用内生成",2),t("button",{type:"button",class:H(["seg-btn",{active:s.value==="paste"}]),onClick:l[2]||(l[2]=m=>s.value="paste")},"复制提示词 / 粘贴回填",2)]),t("label",ua,[l[8]||(l[8]=t("span",null,"描述你想要的组件",-1)),y(t("textarea",{"onUpdate:modelValue":l[3]||(l[3]=m=>E.value=m),rows:"3",class:"ai-area",placeholder:"例如：一个可以增删的闹钟时间组件，封面显示下一项倒计时，点击打开弹窗维护今日计划"},null,512),[[z,E.value]])]),t("p",ga,[u(b(ne),{size:"13",weight:"fill"}),l[9]||(l[9]=x(" 生成会覆盖：名称、描述、图标、封面 JS/CSS、弹窗 HTML/CSS、能力与设置 Schema；不会改动组件 ID、版本与尺寸。填入后可在右侧预览并继续手动调整。 ",-1))]),s.value==="generate"?(g(),h("div",va,[t("div",ba,[t("span",xa,[u(b(se),{size:"13"}),x(f(F.value),1)]),W.value?$("",!0):(g(),h("span",ha,[u(b(X),{size:"13",weight:"fill"}),l[10]||(l[10]=x("未配置应用内 AI（去 AI 助手 → 模型配置）",-1))]))]),t("button",{type:"button",class:"btn primary full",disabled:v.value,onClick:q},[(g(),B(yt(v.value?b(ze):b(nt)),{size:"15",weight:"bold",class:H(v.value?"spin":"")},null,8,["class"])),x(" "+f(v.value?"生成中…":"生成并填入"),1)],8,fa),k.value?(g(),h("div",wa,[t("div",ya,[l[12]||(l[12]=t("span",null,"AI 输出",-1)),t("button",{type:"button",class:"btn ghost xs",onClick:l[4]||(l[4]=m=>N(k.value,"AI 输出"))},[u(b(xt),{size:"12"}),l[11]||(l[11]=x("复制",-1))])]),t("pre",ka,f(k.value),1)])):$("",!0)])):(g(),h("div",Sa,[t("div",za,[(g(!0),h(L,null,j(J.value,m=>(g(),h("div",{key:m.id,class:"prompt-item"},[t("div",Ta,[t("button",{type:"button",class:"prompt-toggle",onClick:V=>R(m.id)},[u(b(ie),{size:"13",class:H(["transition",A.value===m.id?"rot":""])},null,8,["class"]),x(" "+f(m.label),1)],8,Da),t("button",{type:"button",class:"btn ghost xs",onClick:V=>N(m.text,m.label)},[u(b(xt),{size:"12"}),l[13]||(l[13]=x("复制",-1))],8,_a)]),A.value===m.id?(g(),h("pre",Ca,f(m.text),1)):$("",!0)]))),128))]),t("label",Aa,[l[14]||(l[14]=t("span",null,"把外部 AI 返回的内容粘贴到这里",-1)),y(t("textarea",{"onUpdate:modelValue":l[5]||(l[5]=m=>_.value=m),rows:"6",class:"ai-area mono",placeholder:"粘贴 AI 回复（支持 ```json 代码块或纯 JSON）"},null,512),[[z,_.value]])]),t("button",{type:"button",class:"btn primary full",onClick:Y},[u(b(Te),{size:"15",weight:"bold"}),l[15]||(l[15]=x("解析并填入",-1))])]))])])])):$("",!0)]))}}),Ea=et(Na,[["__scopeId","data-v-726ae58e"]]),Ia={class:"designer-workbench animate-fade-in"},Ha={class:"designer-command"},$a={class:"designer-head"},Va={class:"designer-title min-w-0"},Ma={class:"designer-title-icon"},Pa={class:"min-w-0"},Oa={class:"head-actions"},La={class:"signal-grid"},ja={class:"signal"},Ra={class:"signal"},Ja={key:0,class:"warn-banner mt-3"},Ua={class:"starter-grid mt-3"},Wa=["onClick"],qa={key:1,class:"mydesigns mt-3"},Ga=["onClick"],Ka=["onClick"],Ba={key:0,class:"docs"},Fa={class:"d-body"},Ya={class:"editor min-w-0"},Za={class:"editor-toolbar"},Qa={class:"seg"},Xa=["onClick"],tn={class:"sec"},en={class:"field-grid"},an={class:"field"},nn={class:"field"},sn={class:"field"},on={class:"field"},rn={class:"field mt-2"},ln={class:"mt-3"},cn={class:"size-presets"},dn=["onClick"],pn={class:"size-grid mt-2"},mn={class:"size-col"},un={class:"size-col"},gn={class:"size-col"},vn={class:"sec"},bn={class:"field"},xn={class:"field mt-2"},hn={class:"field mt-2"},fn={class:"sec"},wn={class:"field-grid mb-2"},yn={class:"field"},kn={class:"field"},Sn={class:"field"},zn={class:"field mt-2"},Tn={class:"sec"},Dn=["checked","onChange"],_n={class:"cap-text"},Cn={key:0,class:"field mt-2"},An={class:"sec"},Nn={class:"field"},En={class:"field mt-2"},In={class:"preview-col min-w-0"},Hn={class:"preview-head"},$n={class:"preview-stage"},Vn={key:0,class:"preview-error"},Mn={class:"console mt-2"},Pn={class:"console-head"},On={class:"flex items-center gap-1.5"},Ln={class:"console-body"},jn={key:0,class:"console-empty"},Rn={class:"console-level"},Jn={class:"console-text"},Un={class:"actions mt-3"},Wn={class:"apply-group"},qn=["value"],Gn="designer-preview",Kn=tt({__name:"DesignerTab",setup(n){const r=St(),a=zt(),c=["storage","network","openExternal","clipboard.write","notifications"],d=[{id:"basic",label:"基本"},{id:"code",label:"封面"},{id:"modal",label:"弹窗"},{id:"caps",label:"能力"},{id:"advanced",label:"设置"}],p=[{w:2,h:2,label:"2×2"},{w:3,h:3,label:"3×3"}],s=T(ft()),E=T(JSON.parse(JSON.stringify(s.value))),_=T(null),v=T("basic"),k=T(!1),A=T(!1),D=T([]),W=T(null),F=T(0),J=S(()=>{var o,e;return((e=(o=r.config.runtime)==null?void 0:o.sandbox)==null?void 0:e.enabled)===!0});let R=null;bt(s,o=>{R&&clearTimeout(R),R=setTimeout(()=>{E.value=JSON.parse(JSON.stringify(o))},500)},{deep:!0}),Ft(()=>{R&&clearTimeout(R)});const N=S(()=>ot(E.value)),O=S(()=>ot(s.value)),q=S(()=>!N.value.ok||!N.value.install?null:oe(N.value.install,{includeDisabled:!0})),Y=S(()=>{const o=q.value;return o?{id:Gn,tileType:o.id,title:o.label,settings:o.defaultSettings||{},layouts:{desktop:{x:0,y:0,w:o.sizes.default.w,h:o.sizes.default.h}},revision:{updatedAt:Date.now(),deviceId:"designer",sequence:0},createdAt:Date.now()}:null}),w=S(()=>Object.values(r.config.tileInstalls).filter(o=>o.runtime==="sandbox"&&o.source==="local"&&!!o.manifest).sort((o,e)=>(e.updatedAt||0)-(o.updatedAt||0))),l=S(()=>r.config.layout.map(o=>({id:o.id,title:o.title}))),m=T("");bt(l,o=>{!m.value&&o.length&&(m.value=o[0].id)},{immediate:!0});const V=S(()=>{var o;return((o=d.find(e=>e.id===v.value))==null?void 0:o.label)||"编辑"}),G=S(()=>`${s.value.sizes.default.w}x${s.value.sizes.default.h} 默认 / ${s.value.sizes.min.w}x${s.value.sizes.min.h}-${s.value.sizes.max.w}x${s.value.sizes.max.h}`),_t=S(()=>s.value.permissions.length?`${s.value.permissions.length} 项能力`:"无额外能力"),Ct=S(()=>O.value.ok?"结构有效":O.value.error||"结构无效"),At=S(()=>_.value?"编辑已有":"本地草稿"),Nt=o=>{const e=new Set(s.value.permissions);e.has(o)?e.delete(o):e.add(o),s.value.permissions=c.filter(I=>e.has(I))},mt=S({get:()=>s.value.networkHosts.join(`
`),set:o=>{s.value.networkHosts=o.split(/[\n,]/).map(e=>e.trim()).filter(Boolean)}}),Et=o=>{s.value.sizes.default={w:o.w,h:o.h},s.value.sizes.max.w<o.w&&(s.value.sizes.max.w=o.w),s.value.sizes.max.h<o.h&&(s.value.sizes.max.h=o.h)},It=o=>s.value.sizes.default.w===o.w&&s.value.sizes.default.h===o.h,Ht=()=>{r.setSandboxRuntimeEnabled(!0),a.success("已启用 Sandbox JS 本地实验")},$t=o=>{D.value.push({level:o.level||"log",text:o.text||"",at:Date.now()}),D.value.length>200&&D.value.splice(0,D.value.length-200)},Vt=()=>{D.value=[]},Mt=()=>{D.value=[],F.value+=1},ut=()=>{s.value=ft(),_.value=null,D.value=[],v.value="basic"},Pt=o=>{s.value=o,E.value=JSON.parse(JSON.stringify(o)),v.value="code",A.value=!1},Ot=o=>{const e=rt.find(I=>I.id===o);e&&(s.value=e.draft(),_.value=null,D.value=[],v.value="code",a.info(`已加载示例：${e.label}`))},Lt=o=>{const e=wt(o);if(!e){a.error("无法编辑该组件");return}s.value=e,_.value=o.tileType,D.value=[],v.value="code"},gt=()=>{const o=O.value;if(!o.ok||!o.wire)return a.error(`保存失败：${o.error||"组件结构无效"}`),null;const e=r.importTilePackage(o.wire);return e.success?(_.value=e.tileType??null,E.value=JSON.parse(JSON.stringify(s.value)),a.success("已保存到「我的设计」"),e.tileType??null):(a.error(`保存失败：${e.message||"安装失败"}`),null)},jt=()=>{const o=gt();if(!o)return;if(!m.value){a.error("请先选择要添加到的分组");return}const e=r.addExternalTile(m.value,o);e.success?a.success("已应用到分组（首次运行需在桌面点「授权运行」）"):a.error(`应用失败：${e.message||"未知错误"}`)},Rt=()=>{const o=O.value;if(!o.ok||!o.install){a.error(`导出失败：${o.error||"组件结构无效"}`);return}const e=Pe(o.install);if(!e){a.error("导出失败");return}const I=new Blob([e],{type:"application/json"}),i=URL.createObjectURL(I),C=document.createElement("a");C.href=i,C.download=`${s.value.id||"voidtab-widget"}.voidtab-tile.json`,C.click(),setTimeout(()=>URL.revokeObjectURL(i),0),a.success("已导出组件包（可分享给他人导入）")},Jt=()=>{var o;return(o=W.value)==null?void 0:o.click()},Ut=o=>{var i;const e=(i=o.target.files)==null?void 0:i[0];if(!e)return;const I=new FileReader;I.onload=C=>{var Z;try{const Q=JSON.parse(String(((Z=C.target)==null?void 0:Z.result)??"")),qt=kt(Q),vt=wt(qt.install);if(!vt)throw new Error("不是有效的 Sandbox 组件包");s.value=vt,_.value=null,D.value=[],v.value="code",a.success("已导入到设计器，可继续编辑或保存")}catch(Q){a.error(`导入失败：${Q instanceof Error?Q.message:"文件格式不正确"}`)}},I.readAsText(e),o.target.value=""},Wt=o=>{r.uninstallTilePackage(o.tileType)&&(_.value===o.tileType&&ut(),a.success("已删除组件"))};return(o,e)=>{var I;return g(),h("div",Ia,[t("section",Ha,[t("div",$a,[t("div",Va,[t("div",Ma,[u(b(Dt),{size:"20",weight:"duotone"})]),t("div",Pa,[e[25]||(e[25]=t("h3",null,"组件设计",-1)),t("p",null,f(At.value)+" · Sandbox JS · "+f(V.value),1)])]),t("div",Oa,[t("button",{type:"button",class:"btn primary sm",onClick:e[0]||(e[0]=i=>A.value=!0)},[u(b(nt),{size:"14",weight:"bold"}),e[26]||(e[26]=x("AI 生成",-1))]),t("button",{type:"button",class:"btn ghost sm",onClick:ut},[u(b(re),{size:"14",weight:"bold"}),e[27]||(e[27]=x("空白",-1))]),t("button",{type:"button",class:"btn ghost sm",onClick:Jt},[u(b(le),{size:"14",weight:"bold"}),e[28]||(e[28]=x("导入",-1))]),t("button",{type:"button",class:"btn ghost sm",onClick:e[1]||(e[1]=i=>k.value=!k.value)},[u(b(ce),{size:"14",weight:"bold"}),x(f(k.value?"收起":"速查"),1)]),t("input",{ref_key:"fileInput",ref:W,type:"file",class:"hidden",accept:".json,application/json",onChange:Ut},null,544)])]),t("div",La,[t("div",{class:H(["signal",J.value?"ok":"warn"])},[t("b",null,f(J.value?"Sandbox 已启用":"Sandbox 未启用"),1),e[29]||(e[29]=t("span",null,"实时预览运行环境",-1))],2),t("div",{class:H(["signal",O.value.ok?"ok":"bad"])},[t("b",null,f(Ct.value),1),e[30]||(e[30]=t("span",null,"包结构校验",-1))],2),t("div",ja,[t("b",null,f(G.value),1),e[31]||(e[31]=t("span",null,"尺寸约束",-1))]),t("div",Ra,[t("b",null,f(_t.value),1),e[32]||(e[32]=t("span",null,"运行能力",-1))])]),J.value?$("",!0):(g(),h("div",Ja,[u(b(X),{size:"16",weight:"fill",class:"shrink-0 text-amber-500 mt-0.5"}),e[33]||(e[33]=t("div",{class:"flex-1 min-w-0"},[t("div",{class:"text-xs font-bold text-amber-500"},"尚未启用 Sandbox JS 本地实验"),t("div",{class:"text-[11px] opacity-70 mt-0.5"},"实时预览与运行需要先开启该实验能力。")],-1)),t("button",{type:"button",class:"btn primary sm shrink-0",onClick:Ht},"启用")])),e[35]||(e[35]=t("div",{class:"starter-head"},[t("span",{class:"qs-label"},"起步模板")],-1)),t("div",Ua,[(g(!0),h(L,null,j(b(rt),i=>(g(),h("button",{key:i.id,type:"button",class:"starter-card",onClick:C=>Ot(i.id)},[t("span",null,f(i.label),1),t("small",null,f(i.description),1)],8,Wa))),128))]),w.value.length?(g(),h("div",qa,[e[34]||(e[34]=t("span",{class:"qs-label"},"我的设计",-1)),(g(!0),h(L,null,j(w.value,i=>{var C;return g(),h("span",{key:i.tileType,class:H(["design-chip",{active:_.value===i.tileType}])},[t("button",{type:"button",class:"design-chip-main",onClick:Z=>Lt(i)},[u(b(de),{size:"12",weight:"bold"}),x(f(((C=i.manifest)==null?void 0:C.metadata.label)||i.tileType),1)],8,Ga),t("button",{type:"button",class:"design-chip-del",title:"删除",onClick:Z=>Wt(i)},[u(b(pe),{size:"12",weight:"bold"})],8,Ka)],2)}),128))])):$("",!0)]),k.value?(g(),h("section",Ba,[...e[36]||(e[36]=[Yt(`<div class="doc-intro" data-v-c5e652f7> 组件运行在隔离的 iframe 沙箱里，使用固定的 <code data-v-c5e652f7>VoidWidget</code> 运行时 API。下面是从「能跑」到「交付」需要知道的全部约定；不想手写时，点右上角「AI 生成」让 AI 按同一套约定产出代码。 </div><div class="doc-grid" data-v-c5e652f7><div data-v-c5e652f7><h3 class="doc-h" data-v-c5e652f7>1 · 入口与生命周期</h3><p data-v-c5e652f7>封面 JS 必须调用 <code data-v-c5e652f7>VoidWidget.define(...)</code>，在 <code data-v-c5e652f7>mount</code> 里把 DOM 挂到 <code data-v-c5e652f7>ctx.root</code>。需要保存状态用 <code data-v-c5e652f7>this</code>。</p><pre class="doc-code" data-v-c5e652f7>VoidWidget.define({
  async mount(ctx) {
    this._el = document.createElement(&#39;div&#39;);
    ctx.root.appendChild(this._el);
    this._state = await ctx.storage.get(&#39;data&#39;);
    this.render(ctx);
    this._timer = setInterval(() =&gt; this.render(ctx), 1000);
  },
  render(ctx) { /* 重绘封面 */ },
  pause() { clearInterval(this._timer); },   // 不可见时停表
  resume() { /* 重新开表 */ },
  unmount() { clearInterval(this._timer); }, // 清理
  modalEvent(ctx, event) { /* 弹窗动作回调 */ },
});</pre><p data-v-c5e652f7><code data-v-c5e652f7>pause/resume</code> 在标签页隐藏或卡片滚出视口时触发——定时器、轮询请在此停启，避免后台空耗。</p><h3 class="doc-h" data-v-c5e652f7>2 · ctx API</h3><p data-v-c5e652f7><code data-v-c5e652f7>ctx.root</code> 封面根节点 · <code data-v-c5e652f7>ctx.size.placement.w/h</code> 当前格子尺寸（据此自适应 1×1 / 2×2 / 宽卡）· <code data-v-c5e652f7>ctx.settings</code> 实例设置。</p><p data-v-c5e652f7><code data-v-c5e652f7>ctx.storage.get/set/remove(key[, value])</code> 异步本地存储（本实例私有，单值约 8KB）· <code data-v-c5e652f7>ctx.network.fetch(url, init)</code> 经宿主代理（需 network 能力 + 域名白名单，仅 GET/HEAD）。</p><p data-v-c5e652f7><code data-v-c5e652f7>ctx.openUrl</code> · <code data-v-c5e652f7>ctx.copyText</code> · <code data-v-c5e652f7>ctx.notify(title, options)</code> · <code data-v-c5e652f7>ctx.modal.open / ctx.modal.update</code> · <code data-v-c5e652f7>ctx.emit</code>。这些都是计入「每分钟请求配额」的调用，别放进每秒定时器。</p></div><div data-v-c5e652f7><h3 class="doc-h" data-v-c5e652f7>3 · 弹窗与交互协议</h3><p data-v-c5e652f7>用注入的助手打开/刷新弹窗（<code data-v-c5e652f7>updateModal</code> 原地刷新、不重载、保留滚动）：</p><pre class="doc-code" data-v-c5e652f7>// 首次打开
VoidTabDesigner.openModal(ctx, { title, html, width: &#39;760px&#39; });
// 操作后原地刷新（推荐）
VoidTabDesigner.updateModal(ctx, { html, scrollTarget: &#39;[data-vt-section=list]&#39; });
// 插值务必转义
const safe = VoidTabDesigner.escapeHtml(userText);</pre><p data-v-c5e652f7>弹窗里给可点击元素加 <code data-v-c5e652f7>data-vt-action=&quot;动作名&quot;</code>，宿主会回调封面的 <code data-v-c5e652f7>modalEvent(ctx, event)</code>：</p><pre class="doc-code" data-v-c5e652f7>// 普通按钮（点击触发）
&lt;button type=&quot;button&quot; data-vt-action=&quot;del&quot; data-id=&quot;3&quot;&gt;删除&lt;/button&gt;
// 表单（提交时触发，把字段一起带出）
&lt;form data-vt-action=&quot;save&quot;&gt; ... &lt;button type=&quot;submit&quot;&gt;保存&lt;/button&gt; &lt;/form&gt;

modalEvent(ctx, event) {
  // event.name 动作名；event.data 表单字段(name-&gt;值)；
  // event.source.dataset 该元素的 data-*（如 event.source.dataset.id）
}</pre><p class="doc-warn" data-v-c5e652f7>注意：不要给 <code data-v-c5e652f7>input/select/textarea</code> 自身加 <code data-v-c5e652f7>data-vt-action</code>（会被忽略，并妨碍原生时间/日期选择器）。复选框未勾选时字段值为空串。</p><h3 class="doc-h" data-v-c5e652f7>4 · 主题 / 能力 / 交付</h3><p data-v-c5e652f7>封面与弹窗共用主题变量：<code data-v-c5e652f7>--vt-accent</code> · <code data-v-c5e652f7>--vt-text</code> · <code data-v-c5e652f7>--vt-muted</code> · <code data-v-c5e652f7>--vt-surface</code>。</p><p data-v-c5e652f7>用到 storage / network / 外链 / 剪贴板 / 通知，需在「能力」分区勾选；network 还要填域名白名单。</p><p data-v-c5e652f7><b data-v-c5e652f7>保存</b>装到本机「我的设计」；<b data-v-c5e652f7>应用到分组</b>放置实例（首次在桌面点「授权运行」）；<b data-v-c5e652f7>导出</b>生成可分享的组件包 JSON。</p></div></div>`,2)])])):$("",!0),t("div",Fa,[t("section",Ya,[t("div",Za,[t("div",null,[e[37]||(e[37]=t("span",{class:"qs-label"},"编辑区",-1)),t("strong",null,f(V.value),1)])]),t("div",Qa,[(g(),h(L,null,j(d,i=>t("button",{key:i.id,type:"button",class:H(["seg-btn",{active:v.value===i.id}]),onClick:C=>v.value=i.id},f(i.label),11,Xa)),64))]),y(t("div",tn,[t("div",en,[t("label",an,[e[38]||(e[38]=t("span",null,"名称",-1)),y(t("input",{"onUpdate:modelValue":e[2]||(e[2]=i=>s.value.label=i),type:"text"},null,512),[[z,s.value.label]])]),t("label",nn,[e[39]||(e[39]=t("span",null,"ID（唯一）",-1)),y(t("input",{"onUpdate:modelValue":e[3]||(e[3]=i=>s.value.id=i),type:"text",placeholder:"my.widget"},null,512),[[z,s.value.id]])]),t("label",sn,[e[40]||(e[40]=t("span",null,"图标（Phosphor 名）",-1)),y(t("input",{"onUpdate:modelValue":e[4]||(e[4]=i=>s.value.icon=i),type:"text",placeholder:"Code"},null,512),[[z,s.value.icon]])]),t("label",on,[e[41]||(e[41]=t("span",null,"版本",-1)),y(t("input",{"onUpdate:modelValue":e[5]||(e[5]=i=>s.value.version=i),type:"text",placeholder:"0.1.0"},null,512),[[z,s.value.version]])])]),t("label",rn,[e[42]||(e[42]=t("span",null,"描述",-1)),y(t("input",{"onUpdate:modelValue":e[6]||(e[6]=i=>s.value.description=i),type:"text"},null,512),[[z,s.value.description]])]),t("div",ln,[e[49]||(e[49]=t("div",{class:"field-label"},"默认尺寸",-1)),t("div",cn,[(g(),h(L,null,j(p,i=>t("button",{key:i.label,type:"button",class:H(["chip",{accent:It(i)}]),onClick:C=>Et(i)},f(i.label),11,dn)),64))]),t("div",pn,[t("div",mn,[e[44]||(e[44]=t("span",null,"默认",-1)),t("div",null,[y(t("input",{"onUpdate:modelValue":e[7]||(e[7]=i=>s.value.sizes.default.w=i),type:"number",min:"1",max:"6"},null,512),[[z,s.value.sizes.default.w,void 0,{number:!0}]]),e[43]||(e[43]=x("×",-1)),y(t("input",{"onUpdate:modelValue":e[8]||(e[8]=i=>s.value.sizes.default.h=i),type:"number",min:"1",max:"6"},null,512),[[z,s.value.sizes.default.h,void 0,{number:!0}]])])]),t("div",un,[e[46]||(e[46]=t("span",null,"最小",-1)),t("div",null,[y(t("input",{"onUpdate:modelValue":e[9]||(e[9]=i=>s.value.sizes.min.w=i),type:"number",min:"1",max:"6"},null,512),[[z,s.value.sizes.min.w,void 0,{number:!0}]]),e[45]||(e[45]=x("×",-1)),y(t("input",{"onUpdate:modelValue":e[10]||(e[10]=i=>s.value.sizes.min.h=i),type:"number",min:"1",max:"6"},null,512),[[z,s.value.sizes.min.h,void 0,{number:!0}]])])]),t("div",gn,[e[48]||(e[48]=t("span",null,"最大",-1)),t("div",null,[y(t("input",{"onUpdate:modelValue":e[11]||(e[11]=i=>s.value.sizes.max.w=i),type:"number",min:"1",max:"6"},null,512),[[z,s.value.sizes.max.w,void 0,{number:!0}]]),e[47]||(e[47]=x("×",-1)),y(t("input",{"onUpdate:modelValue":e[12]||(e[12]=i=>s.value.sizes.max.h=i),type:"number",min:"1",max:"6"},null,512),[[z,s.value.sizes.max.h,void 0,{number:!0}]])])])])])],512),[[K,v.value==="basic"]]),y(t("div",vn,[e[53]||(e[53]=t("div",{class:"designer-note mb-2"},[x(" 封面运行在卡片 iframe 中，可读取 "),t("code",null,"ctx.size.placement.w/h"),x(" 判断 1×1、2×2 或宽卡展示内容。 样式可直接使用 "),t("code",null,"--vt-accent"),x(" / "),t("code",null,"--vt-text"),x(" 等主题变量。 ")],-1)),t("label",bn,[e[50]||(e[50]=t("span",null,"封面 JS",-1)),u(U,{modelValue:s.value.entryCode,"onUpdate:modelValue":e[13]||(e[13]=i=>s.value.entryCode=i),language:"javascript",rows:16},null,8,["modelValue"])]),t("label",xn,[e[51]||(e[51]=t("span",null,"封面 CSS",-1)),u(U,{modelValue:s.value.styles,"onUpdate:modelValue":e[14]||(e[14]=i=>s.value.styles=i),language:"css",rows:6},null,8,["modelValue"])]),t("label",hn,[e[52]||(e[52]=t("span",null,"初始 HTML（可选）",-1)),u(U,{modelValue:s.value.html,"onUpdate:modelValue":e[15]||(e[15]=i=>s.value.html=i),language:"xml",rows:3},null,8,["modelValue"])])],512),[[K,v.value==="code"]]),y(t("div",fn,[e[58]||(e[58]=t("div",{class:"designer-note mb-2"},[x(" 这里是默认弹窗模板；封面 JS 可在点击时调用 "),t("code",null,"VoidTabDesigner.openModal(ctx, { html, width: '900px', height: '72vh' })"),x(" 传入实时数据覆盖模板内容。 弹窗 iframe 会继承同一套主题变量，适合封面和详情保持一致视觉。 弹窗内容可以直接使用列表、输入框、数字框、文本域等常规布局。 ")],-1)),t("div",wn,[t("label",yn,[e[54]||(e[54]=t("span",null,"弹窗宽度",-1)),y(t("input",{"onUpdate:modelValue":e[16]||(e[16]=i=>s.value.modalWidth=i),type:"text",placeholder:"760px / 80vw"},null,512),[[z,s.value.modalWidth]])]),t("label",kn,[e[55]||(e[55]=t("span",null,"弹窗高度",-1)),y(t("input",{"onUpdate:modelValue":e[17]||(e[17]=i=>s.value.modalHeight=i),type:"text",placeholder:"620px / 72vh"},null,512),[[z,s.value.modalHeight]])])]),t("label",Sn,[e[56]||(e[56]=t("span",null,"弹窗 HTML",-1)),u(U,{modelValue:s.value.modalHtml,"onUpdate:modelValue":e[18]||(e[18]=i=>s.value.modalHtml=i),language:"xml",rows:10},null,8,["modelValue"])]),t("label",zn,[e[57]||(e[57]=t("span",null,"弹窗 CSS",-1)),u(U,{modelValue:s.value.modalStyles,"onUpdate:modelValue":e[19]||(e[19]=i=>s.value.modalStyles=i),language:"css",rows:7},null,8,["modelValue"])])],512),[[K,v.value==="modal"]]),y(t("div",Tn,[(g(),h(L,null,j(c,i=>t("label",{key:i,class:"cap-row"},[t("input",{type:"checkbox",checked:s.value.permissions.includes(i),onChange:C=>Nt(i)},null,40,Dn),t("span",_n,[t("b",null,f(b(ht)[i].label),1),t("small",null,f(b(ht)[i].detail),1)])])),64)),s.value.permissions.includes("network")?(g(),h("label",Cn,[e[59]||(e[59]=t("span",null,"允许的网络域名（每行一个，支持 *.example.com）",-1)),y(t("textarea",{"onUpdate:modelValue":e[20]||(e[20]=i=>mt.value=i),rows:"3",class:"code-area mono",placeholder:"api.example.com"},null,512),[[z,mt.value]])])):$("",!0)],512),[[K,v.value==="caps"]]),y(t("div",An,[t("label",Nn,[e[60]||(e[60]=t("span",null,"设置 Schema JSON",-1)),u(U,{modelValue:s.value.settingsSchemaText,"onUpdate:modelValue":e[21]||(e[21]=i=>s.value.settingsSchemaText=i),language:"json",rows:8,placeholder:'{"type":"object","properties":{}}'},null,8,["modelValue"])]),t("label",En,[e[61]||(e[61]=t("span",null,"分类",-1)),y(t("input",{"onUpdate:modelValue":e[22]||(e[22]=i=>s.value.category=i),type:"text",placeholder:"local"},null,512),[[z,s.value.category]])])],512),[[K,v.value==="advanced"]])]),t("section",In,[t("div",Hn,[t("div",null,[e[62]||(e[62]=t("span",{class:"qs-label"},"实时预览",-1)),t("strong",null,f(s.value.label||"未命名组件"),1)]),t("button",{type:"button",class:"btn ghost sm",onClick:Mt},[u(b(fe),{size:"13",weight:"bold"}),e[63]||(e[63]=x("重新运行",-1))])]),t("div",$n,[N.value.ok?Y.value&&q.value?(g(),B(me,{key:F.value+":"+(((I=N.value.install)==null?void 0:I.sha256)||""),tile:Y.value,definition:q.value,enabled:J.value,debug:!0,"preview-mode":!0,onLog:$t},null,8,["tile","definition","enabled"])):$("",!0):(g(),h("div",Vn,[u(b(X),{size:"18",weight:"fill"}),t("span",null,f(N.value.error),1)]))]),t("div",{class:H(["status-row mt-2",N.value.ok?"ok":"bad"])},[(g(),B(yt(N.value.ok?b(ue):b(X)),{size:"14",weight:"fill"})),t("span",null,f(N.value.ok?"组件结构有效":N.value.error),1)],2),t("div",Mn,[t("div",Pn,[t("span",On,[u(b(ge),{size:"13",weight:"bold"}),e[64]||(e[64]=x("调试控制台",-1))]),t("button",{type:"button",class:"btn ghost xs",onClick:Vt},"清空")]),t("div",Ln,[D.value.length?$("",!0):(g(),h("p",jn,"console.log / 运行错误会显示在这里。")),(g(!0),h(L,null,j(D.value,(i,C)=>(g(),h("div",{key:C,class:H(["console-line",i.level])},[t("span",Rn,f(i.level),1),t("span",Jn,f(i.text),1)],2))),128))])]),t("div",Un,[t("button",{type:"button",class:"btn primary",onClick:gt},[u(b(he),{size:"15",weight:"bold"}),e[65]||(e[65]=x("保存",-1))]),t("button",{type:"button",class:"btn ghost",onClick:Rt},[u(b(ve),{size:"15",weight:"bold"}),e[66]||(e[66]=x("导出",-1))]),t("div",Wn,[y(t("select",{"onUpdate:modelValue":e[23]||(e[23]=i=>m.value=i),class:"group-select"},[(g(!0),h(L,null,j(l.value,i=>(g(),h("option",{key:i.id,value:i.id},f(i.title),9,qn))),128))],512),[[Zt,m.value]]),t("button",{type:"button",class:"btn ghost",onClick:jt},[u(b(be),{size:"15",weight:"bold"}),e[67]||(e[67]=x("应用到分组",-1))])])])])]),u(Ea,{show:A.value,draft:s.value,onClose:e[24]||(e[24]=i=>A.value=!1),onApply:Pt},null,8,["show","draft"])])}}}),Bn=et(Kn,[["__scopeId","data-v-c5e652f7"]]),Fn={key:0,class:"fixed inset-0 z-[120] flex items-stretch justify-center p-0 sm:p-4 md:p-8"},Yn={class:"relative w-full max-w-6xl h-full sm:h-[92vh] flex flex-col overflow-hidden rounded-none sm:rounded-2xl shadow-2xl border bg-[var(--settings-surface)] text-[var(--settings-text)]",style:{"border-color":"var(--settings-border)"},role:"dialog","aria-modal":"true","aria-labelledby":"designer-modal-title","data-modal":"1"},Zn={class:"dm-header"},Qn={class:"flex items-center gap-3 min-w-0"},Xn={class:"dm-icon"},ts={class:"dm-body"},es=tt({__name:"DesignerModal",props:{show:{type:Boolean}},emits:["close"],setup(n,{emit:r}){const a=n,c=r;return xe(()=>a.show,()=>c("close")),(d,p)=>(g(),B(Xt,{name:"fade"},{default:Qt(()=>[n.show?(g(),h("div",Fn,[t("div",{class:"absolute inset-0 bg-black/55 backdrop-blur-md",onClick:p[0]||(p[0]=s=>c("close"))}),t("section",Yn,[t("header",Zn,[t("div",Qn,[t("div",Xn,[u(b(Dt),{size:"20",weight:"fill"})]),p[2]||(p[2]=t("div",{class:"min-w-0"},[t("h2",{id:"designer-modal-title",class:"font-extrabold text-sm tracking-wide truncate"},"组件设计"),t("p",{class:"text-xs opacity-60 mt-0.5 truncate"},"独立的全屏设计器，适合编写代码与实时调试")],-1))]),t("button",{type:"button",class:"dm-close","aria-label":"关闭组件设计",title:"关闭 (Esc)",onClick:p[1]||(p[1]=s=>c("close"))},[u(b(Tt),{size:"22"})])]),t("div",ts,[u(Bn)])])])):$("",!0)]),_:1}))}}),bs=et(es,[["__scopeId","data-v-0dac84d3"]]);export{bs as default};
